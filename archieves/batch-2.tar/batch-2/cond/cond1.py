#!/usr/bin/env python

a = input("please enter the value of a:") 
b = int(raw_input("please enter the value of b:"))

if a > b:
    print a, "is greater than ",b 
elif a < b:
    print a, "is lesser than ",b
else:
    print a," is equal to",b
    
