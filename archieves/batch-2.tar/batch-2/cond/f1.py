#!/usr/bin/python

# fish
animal = raw_input("please enter the animal name:")

if animal == 'fish':
  print "The animal name is %s" %(animal)
  type_fish = raw_input("please enter the name of fish:")
  if type_fish == 'toffu':
    print "the name of the fish is %s" %(type_fish)
  elif type_fish == 'peru':
    print "the name of the fish is %s" %(type_fish)
  else:
    print "we dont hve toffu"
else:
  print "The animal is not a fish"


