#!/usr/bin/python

field = raw_input('please enter your field:')
print type(field)

if field == 'eng':
  print "Hello i am an engineer"
  option = raw_input('please enter you options:')
  if ( option == 'csc' or option == 'mec' ):
    print "ok!! we have the course for you \n"
  else:
    print "sorry!! we don't have the course available"  
elif field == 'med':
  print "Hello i am an medico"

