#!/usr/bin/python

try:
  value1 = input("Please enter your first number")
  value2 = input("please enter your second number")
except NameError:
  print "please enter numbers only \n"

try:
  print float(value1)/value2
except NameError,error:
  print "Both the values should be integers \n"
except ZeroDivisionError,error1:
  print "Make sure the bottom number is not zero \n"


# This is the errors printing.
print "%s \n" %(error)


