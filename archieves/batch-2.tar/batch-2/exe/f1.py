#!/usr/bin/python

try:
  value1 = input("Please enter your first number")
  value2 = input("please enter your second number")
except NameError:
  print "please enter numbers only \n"

try:
  print "division of two numbers is : " , float(value1)/value2
except (NameError,ZeroDivisionError):
  print " \n please enter a valid number"
