#/usr/bin/env python

number = 7
test = True

while test:
  quit_game = raw_input("do you want to continue the game .. quit to exit: \n")
  if quit_game == 'quit':
    break

  guess = int(raw_input("please enter the number:"))
  
  if guess == number:
    print "Congo !!! you have guessed the right number \n"
    test = False
  else:
    print "Better luck next time \n"

print "hello we are out of the game \n"
