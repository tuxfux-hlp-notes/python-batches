#!/usr/bin/python

name = raw_input("Please enter your name:")
age  = int(raw_input("please enter your age:"))

print "*" * 30 , "\n"
print "my name : %s - my age : %s" %(name,age)
print "*" * 30 , "\n"

raw_input("... Please press enter to exit .... ")
