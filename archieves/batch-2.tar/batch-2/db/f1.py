#!/usr/bin/python

# Importing the modules.

import MySQLdb as mdb

# lets open a connection

con = mdb.connect('localhost','testuser','testuser','mydata')
                 # hostname,user,pass,database

# making a cursor.

cur = con.cursor()

# execute some mysql commands

cur.execute("select user()")

# fetching one record.

username = cur.fetchone()
print "username: %r" %(username)

