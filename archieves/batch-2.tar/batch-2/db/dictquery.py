mporting the modules.
  4 
  5 import MySQLdb as mdb
  6 
  7 # lets open a connection
  8 
  9 con = mdb.connect('localhost','testuser','testuser','mydata')
 10                  # hostname,user,pass,database
 11 
 12 # making a cursor.
 13 
 14 cur = con.cursor(mdb.cursors.DictCursor)
 15 
 16 # execute some mysql commands
 17 
 18 #cur.executemany("insert into students(id,name) values (%s,%s)",[(14,'hari')    ,(2,'priya'),(3,'vicky')])
 19 #cur.execute("insert into students values(1,'krishan') ")
 20 cur.execute("select * from students")
 21 
 22 # fetching the values.
                                                              1,1           Top
/bin/bash: 2: command not found

#username = cur.fetchone()
#print "username: %r" %(username)
'''
