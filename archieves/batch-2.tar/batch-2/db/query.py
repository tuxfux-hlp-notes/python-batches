#!/usr/bin/python

# Importing the modules.

import MySQLdb as mdb

# lets open a connection

con = mdb.connect('localhost','testuser','testuser','mydata')
                 # hostname,user,pass,database

# making a cursor.

cur = con.cursor()

# execute some mysql commands

#cur.executemany("insert into students(id,name) values (%s,%s)",[(14,'hari'),(2,'priya'),(3,'vicky')])
#cur.execute("insert into students values(1,'krishan') ")
cur.execute("select * from students")

# fetching the values.

rows = cur.fetchall()
for row in rows:
  print row

# commiting the values.

con.commit()

# fetching one record.

#username = cur.fetchone()
#print "username: %r" %(username)

