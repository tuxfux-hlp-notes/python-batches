#!/usr/bin/python

import f4

print 'My class is :' , f4.name
print f4.fun_name('python')

def add():
  return "addition of two numbers is ", 2 + 3

print add()
