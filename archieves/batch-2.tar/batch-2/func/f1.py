#!/usr/bin/python

# input values
a = input("Please enter the value for a:")
b = input("Please enter the value for b:")

# we are defining the function

def gl(a,b):
  if a > b:
    print "a:%d is greater than b%d" %(a,b)
  elif b > a:
    print "b:%d is greater than a:%d" %(b,a)
  else:
    print "%d,%d both the values are equal" %(a,b)

# calling the function.
gl(a,b)
