#!/usr/bin/python

a = 10
print "value of a:%d is :" %(a)

def local_fun():
  a = 5
  print "The value of a is %d" %(a)
  global a
  print "The value of a is %d" %(a)

local_fun()
