#!/usr/bin/python

if __name__ == '__main__':
  print "This is the code for main program \n"
else:
  name = "tcloud python"
  def fun_name(name):
    return "The course topic is  %s \n" %(name)
