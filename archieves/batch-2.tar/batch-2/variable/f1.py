#!/usr/bin/python
# ask for two numbers and add them.

num1 = int(raw_input("please enter the number1:"))
num2 = int(raw_input("please enter the number1:"))

sum = num1 + num2 
print "The addition of both of the numbers is: %d"  %(sum)

