#!/usr/bin/python
num1 = input("please enter the number1:")
num2 = input("please enter the number2:")
sum = num1 + num2
print "sum:%d" %(sum)
