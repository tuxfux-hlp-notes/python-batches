if 2 < 5:
  print "2 is less than 5"
