#!/usr/bin/python

if __name__ == '__main__':
  print "hello this is the main program \n"
else:
  print "hello this is parts of product 3.0\n" 
  today_version = '3.0'
  
