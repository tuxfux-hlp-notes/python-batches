#!/usr/bin/python

def Perl():
  print 'Welcome to version of perl 5.6'
