#!/usr/bin/python

def Linux():
  print 'Welcome to Linux version 6.3'
