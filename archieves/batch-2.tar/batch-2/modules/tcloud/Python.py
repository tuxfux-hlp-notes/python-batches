#!/usr/bin/python

def Python():
  print 'Welcome to Python version 2.7.4'
