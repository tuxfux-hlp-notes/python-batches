#!/usr/bin/python
print "hello world"
print "today is a great day"
name="santosh"
if name == 'santosh':
    print "hello santosh"
else:
    print "Hello there .. are you santosh ? "
    
