#!/usr/bin/python

import sys
sys.path.append('/home/visitor/python-examples/batch-10/func/mod/new')
import nfirst

print "This is version number %s" %(nfirst.version)
print nfirst.my_function()
