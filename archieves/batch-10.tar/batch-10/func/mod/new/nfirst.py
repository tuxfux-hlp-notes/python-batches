#!/usr/bin/python

version='2.0'
def my_function():
  ''' This is a simple function
      Hey this is just to help you understand docstring'''

  return 'Hello'


if __name__ == '__main__':
  name = raw_input("please enter your name:")
  print name
  print version
  print my_function()
else:
  print "I am importing them module"
