#!/usr/bin/python
def third():
  ''' Hello this is my third module '''
  return "Linux third Module"
