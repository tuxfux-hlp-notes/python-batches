#!/usr/bin/python
def second():
  ''' Hello this is my second module '''
  return "Linux second Module"
