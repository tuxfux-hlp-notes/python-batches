#!/usr/bin/python
def first():
  ''' Hello this is my first module '''
  return "Linux first Module"
