#!/usr/bin/python

def my_mult(num,limit=10):
  ''' This is for multiplication.
      mult(2) , print till range of 10
      mult(2,val), print till range of n
  '''
  for i in range(1,limit+1):
    print "%d * %d = %d" %(num,i,num*i)

my_mult(10,limit=20)
