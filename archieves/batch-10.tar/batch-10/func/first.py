#!/usr/bin/python

def my_addition(a,b):
  add = a + b
  print add



# main

num1 = int(raw_input("Please enter my number1"))
num2 = int(raw_input("Please enter my number2"))

print "addition of num1 and num2" , my_addition(num1,num2)
