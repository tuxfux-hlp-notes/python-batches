#!/usr/bin/python

try:
  num1 = int(raw_input("please enter the number1:"))
  num2 = int(raw_input("please enter the number2:"))
  print num1,num2
  print num1/num2
except ZeroDivisionError,error:
  print "Please don't enter zero on denominators"
except ValueError,error1:
  print "please enter numeric values only"

print "my error1: {} ".format(error1) 
