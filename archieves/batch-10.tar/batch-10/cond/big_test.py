#!/usr/bin/python
num1 = int(raw_input("please enter number1:"))
num2 = int(raw_input("please enter number2:"))
num3 = int(raw_input("please enter number3:"))
if num1 > num2 and num1 > num3:
    print "%d is greatert number" %(num1)
elif num2 > num1 and num2 > num3:
    print "%d is greatest number" %(num2)
elif num3 > num1 and num3 > num2:
    print "%d is greatest number" %(num3)
else:
    print "%d,%d,%d are all equal" %(num1,num2,num3)
    
