#!/usr/bin/python
import sys

number = 7

yn = raw_input("Do you want to play this game?")
if yn == 'n':
  sys.exit() 

while ( True ):
    gnumber = int(raw_input("please guess the number"))
    if gnumber > number:
      print "opps !!! you just hit a bigger number"
    elif gnumber < number:
      print "opps !!! you just hit a smaller number"
    else:
      print "Wow !!! you have divine sence"
      break 

print "Thank you for playing the game"
print "Hope you visiting me again"

