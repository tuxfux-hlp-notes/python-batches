#!/usr/bin/python

item = raw_input("Please enter your item(fish,chicken):")
if item == 'fish':
  fish_type = raw_input("Please enter the type of fish(toffu,peru,solomon):")
  if fish_type == 'toffu' or fish_type == 'Toffu':
    print "we have %s fish" %(fish_type)
    print "Hope you like the fish"
  elif fish_type == 'peru' or fish_type == 'Peru':
        print "we have %s fish" %(fish_type)
        print "Hope you like the fish"
  else:
      print "we dont have %s type fishes" %(fish_type)
else:
  print "Thanks for visiting the market \n"
  print "Please visit again !!! \n"

