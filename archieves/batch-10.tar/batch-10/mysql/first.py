#!/usr/bin/python
import MySQLdb as mdb
con = mdb.connect('localhost','tuxfux','tuxfux','my_latest')
cur = con.cursor()
cur.execute("select user()")
username = cur.fetchone()

print "The username i am connected to is %s" %(username)
