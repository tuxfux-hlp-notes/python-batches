#!/usr/bin/python
import logging as l
l.debug("Hello this is a debug information")
l.info("hello this is just information")
l.warning("Hello i am trying to warn you")
l.error("Hello this is error")
l.critical("Hello our app is down")

