#!/usr/bin/python
import re

answer = raw_input("do you want to continue the game(yes/no)")
if re.match('yes',answer,re.I):
  print "lets play the game"
else:
  print "lets exit the game"

