#!/usr/bin/python
import re
import subprocess as s
output = s.Popen(['df','-h','/dev/sda1'],stdout=s.PIPE)
tail_output = s.Popen(['tail','-n','1'],stdin=output.stdout,stdout=s.PIPE)
#print output.communicate()
final_output=re.sub('G','',tail_output.communicate()[0].split()[3])
print final_output
