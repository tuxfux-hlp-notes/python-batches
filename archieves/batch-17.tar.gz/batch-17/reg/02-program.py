#!/usr/bin/python
import re
reg = re.compile('[a-z.]+@[a-z]+[.][a-z]+',re.I)
#tuxfux.hlp@gmail.com
#tuxfux.@gmail.com

f = open('email.txt','rb')
my_value = f.read()
f.close()

print reg.findall(my_value)
