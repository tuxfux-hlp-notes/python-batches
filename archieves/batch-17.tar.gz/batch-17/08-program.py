#!/usr/bin/python

try:
  num1 = int(raw_input("please enter the number1:"))
  num2 = int(raw_input("please enter the number2:"))
except ValueError:
  print "Hello you have got to enter numbers"
else:
  try:
    print num1/num2
  except ZeroDivisionError:
    print "you need to have your denominator as not zero"
