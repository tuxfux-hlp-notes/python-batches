#!/usr/bin/python

name = raw_input("please enter your name:")
age = int(raw_input("please enter your age:"))
gender = raw_input("please enter your gender:")

print "name:%s,age:%s,gender:%s" %(name,age,gender)
