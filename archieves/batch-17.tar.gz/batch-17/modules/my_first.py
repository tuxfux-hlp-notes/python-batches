#!/usr/bin/python
# usage: understanding modules

version=2.0

def My_Add(a,b):
  ''' This is for addition '''
  return a+b

def My_Div(a,b):
  ''' This is for multiplicaltion'''
  return a/b

def My_Mult(a,b):
  return a*b

def My_SubS(a,b):
  return a - b

if __name__ == '__main__':
  print "I am working on modules !!! Hurrar i got them woking"
  print "addition of two numbers %d" %(My_Add(2,3))

