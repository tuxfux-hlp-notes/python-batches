#!/usr/bin/python
import sys
sys.path.insert(0,'/home/tcloudost/python-examples/batch-17/modules/')
from my_first import My_Add
print "addition of two numbers is %d" %(My_Add(5,6))
