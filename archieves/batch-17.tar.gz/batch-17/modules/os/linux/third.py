#!/usr/bin/python

def we_first():
  return "this is my linux my_first"

def we_second():
  return "this is my linux my_second"

def we_third():
  return "this is my linux my_third"
