#!/usr/bin/python

def my_first():
  return "this is my linux my_first"

def my_second():
  return "this is my linux my_second"

def my_third():
  return "this is my linux my_third"
