#!/usr/bin/python

def our_first():
  return "this is my linux my_first"

def our_second():
  return "this is my linux my_second"

def our_third():
  return "this is my linux my_third"
