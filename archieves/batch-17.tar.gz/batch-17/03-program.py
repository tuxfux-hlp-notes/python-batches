#!/usr/bin/python
# usage : kiosk
print "welcome to the market \n"
my_item = raw_input("please let us know what you want:(fish/mutton/chicken)")
if my_item == 'fish':
  print "welcome to the fish market"
  my_fish = raw_input("please enter the type of the fish:(peru,rohu,solomon)")
  if my_fish == 'peru' or my_fish == 'PERU':
    print "we have peru, what is the quantity you need"
    print "thanks for buying please come back"
  elif my_fish == 'rohu':
    print "we have rohu, what is the quantity you need"
    print "thanks for buying please come back"
  elif my_fish == 'solomon':
    print "we have solomon, what is the quantity you need"
    print "thanks for buying please come back"
  else:
    print "sorry we dont have your fish type"
    print "please visit us again"    
elif my_item == 'mutton':
  pass
elif my_item == 'chicken':
  pass
else:
  pass
