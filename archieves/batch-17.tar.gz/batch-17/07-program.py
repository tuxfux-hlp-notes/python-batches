#!/usr/bin/env python
days = [ 'today','yesterday','tomorrow','dayafter']

#assg 1:
for value in days:
  print "%s,%d" %(value,len(value))
  
# assg 2:
# today - firstelement + remaing code
for value in days:
  print value[0:(days.index(value) +1)].upper() + value[(days.index(value) +1):]
  
# assg 3:
odd=list()
even=list()
for value in range(1,11):
  if value % 2 == 0:
    even.append(value)
  else:
    odd.append(value)

print even
print odd
