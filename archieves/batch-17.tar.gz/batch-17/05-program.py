#!/usr/bin/python
#Usage: number guessing game
# break
# exit
# assignment : make sure the number is asked only 3 times

import sys


answer = raw_input("do you want to play the game ?(yes,no)")
if answer == 'no':
	sys.exit()

number = 7
#test = True

while True:
  my_guess = int(raw_input("please enter your number:"))
  if my_guess == number:
    print "congratulations !!!"
    #test = False
    break
  elif my_guess < number:
    print "buddy !!! you choose a lesser number"
  elif my_guess > number:
    print "buddy !!! you chose a greater number"
    
print "Thanks for playing the game"

