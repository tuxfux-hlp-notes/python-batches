#!/usr/bin/python
for i in range(1,11):
	if i == 5:
		continue
	print i

# take a binary number : 1001
# convert it into interger
# 1 *  2**3 + 0 * 2 **2 + 0 * 2**1 + 0 * 2**0= 9
# hint: while/for,math,print