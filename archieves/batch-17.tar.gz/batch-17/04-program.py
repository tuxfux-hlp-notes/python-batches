#!/usr/bin/python

num1 = int(raw_input("please enter the number1:"))
num2 = int(raw_input("please enter the number2:"))
num3 = int(raw_input("please enter the number3:"))

if  num1 > num2 and num1 > num3:
  print "%d is greter then %d and %d" %(num1,num2,num3)
elif num2 > num3 and num2 > num1:
  print "%d is greter then %d and %d" %(num2,num1,num3) 
elif num3 > num1 and num3 > num2:
  print "%d is greter then %d and %d" %(num3,num1,num2)
else:
  print "%d,%d,%d are all equal" %(num1,num2,num3)
