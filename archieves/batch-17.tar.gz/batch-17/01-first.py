#!/usr/bin/python
# Author:
# usage:
# logs:
print "hello world"
