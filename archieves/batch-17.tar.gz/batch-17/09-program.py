#!/usr/bin/python
import MySQLdb as mdb
con = mdb.connect('localhost','mydb2','mydb2','mydb2')
cur = con.cursor()
cur.execute('create table students(rollno int,name varchar(25))')
con.commit()
