#!/usr/bin/python
import logging as l
l.debug("This is a debug message")
l.info("This is an information message")
l.warning("this is just an warning")
l.error("we hit on an error")
l.critical("something bad or critical happened")
