#!/usr/bin/python
space = int(raw_input("please enter the disk space:"))
import logging as l
l.basicConfig(filename='new.log',filemode='a',level=l.DEBUG,format='%(asctime)s - %(levelname)s - %(message)s',datefmt='%c' )
if space < 50:
	l.info("Our disk scan is going great")
elif space > 50 and space < 70:
	l.debug("Our disk is doing great")
elif space > 70 and space < 80:
	l.warning("we are about to hit the disk space")
elif space > 80 and space < 90:
	l.error("our disk is hitting on error")
elif space > 90:
	l.critical("Our disk space is hitting critical state")