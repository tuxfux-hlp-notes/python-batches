#!/usr/bin/python

# for
#
# no condition testing
# start and end

# while
# 
# condition
# depending on truth it will execute.

# 'python' is a sequence of characters.

for val in 'python':
  print val

for course in ('python','perl','shell','django','linux','mysql'):
  print course

for i in range(1,11):
  print i
