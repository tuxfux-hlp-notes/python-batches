#!/usr/bin/python
# usage : number guesssing game.
import sys

number = 7
#test = True

game = raw_input("Do you want to continue the game(y/n):")
if game == 'n':
  sys.exit()    # kick me out of the program
  

# while will always look for the truth of the condition
while True:
  guess = int(raw_input("please enter the number:"))
  if guess > number:
    print "you guessed the number slightly larger"
  elif guess < number:
    print "you guessed the number slightly smaller"
  elif guess == number:
    print "congratulations !!!"
    #test=False
    break    # take you out of the loop

print "Thanks for playing the game !!! \n";

# Assignment : max number of attempts is only 3

