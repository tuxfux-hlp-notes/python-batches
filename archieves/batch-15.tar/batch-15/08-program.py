#!/usr/bin/python

# list - single dimension array.
# numpy - multi dimension array.

# defination of a list
fruits = ["apple","banana","gauva","pineapple"]
# index      0       1        2         3
print type(fruits)
my_fruits = []
print type(my_fruits)
my_names=list()
print type(my_names)

# how to see the values of a list
print fruits[0]
print fruits[0:2]
print fruits[:2]
print fruits[2:4]
print fruits[2:]
print fruits
print fruits[:]

# Assigning the values.
fruits[0] = 'Apple'
print fruits
fruits[1:3] = ["Banana","Gauva"]
print fruits

print "banana" in fruits
print "Banana" in fruits

for i in ('banana','Banana'):
  if i in fruits:
    print "we have the fruit %s in our catalog" %(i)
  else:
    print "we don't have the %s" %(i)
    
 # Traversing a list

for i in fruits:
  print "the element is %s" %(i)
  
# List operations

my_num = [1,2,3]
my_ones = [1,1,1]
my_mon = ['jan','feb','mar']

print my_num + my_mon

print my_ones * 3
