Assignments

1. create a two lists even and odd having numbers between 1 to 30.
 hint : for,range,list functions
 
2. create a list called as words = ['happy','today','sunday','always']

part 1:
  happy 5
  today 5
  sunday 5
  always 6

hint : len(),for

part 2:

Happy
TOday
SUNday
ALWAys

hint: for,function of list,string functions
