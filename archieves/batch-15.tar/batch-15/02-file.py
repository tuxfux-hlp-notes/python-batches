#!/usr/bin/python

num1 = int(raw_input("please enter the number:"))
num2 = int(raw_input("please enter the number:"))

print "addition of two numbers is %d " %(num1 + num2)
raw_input(".. please enter to exit .. ")
