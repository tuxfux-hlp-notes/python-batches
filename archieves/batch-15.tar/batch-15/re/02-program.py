#!/usr/bin/python
import re

#reg = re.compile('[a-z.]+@[a-z]+[.][a-z]+')
#reg = re.compile('[a-z.]+@\w+[.]\w+')
f = open("email_address.txt",'rb')
my_file = f.read()
f.close()

print reg.findall(my_file)


