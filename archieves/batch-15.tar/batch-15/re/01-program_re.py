#!/usr/bin/python

import re
reg = re.compile('yes',re.I)
answer = raw_input("Do you want to continue the game:(yes/no):")
if reg.match(answer):
  print "welcome to the game"
else:
  print "Please visit us again !! Apologies for not liking the game"
  

# import re
# re.match
# re.search
# re.compile
