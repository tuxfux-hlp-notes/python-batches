#!/usr/bin/python
# make sure your program always ends with .py

version='2.0'
def my_add(a,b):
  ''' function for additions '''
  return a+b

def my_sub(a,b):
  ''' function for substactions '''
  return a-b

def my_multi(a,b):
  ''' function for multiplications '''
  return a*b

def my_div(a,b):
  ''' function for divisions '''
  return a/b
  
if __name__ == '__main__':  
  print "addition of two numbers: %d" %(my_add(2,3))

