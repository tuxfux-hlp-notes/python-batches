#!/usr/bin/python
import sys
sys.path.append('/home/tcloudost/python-examples/batch-15/modules/extra')
import first
print "addition of two numbers:%d" %(first.my_add(2,3))

# assignment
# trim this whole path /home/tcloudost/python-examples/batch-15/modules/
# hint : import os
