#!/usr/bin/python

def my_g1():
  return 'my_f1'

def my_g2():
  return 'my_f2'

def my_g3():
  return 'my_f3'
