#!/usr/bin/python

def my_f1():
  return 'my_f1'

def my_f2():
  return 'my_f2'

def my_f3():
  return 'my_f3'
