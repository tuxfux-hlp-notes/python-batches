#!/usr/bin/python

def my_h1():
  return 'my_f1'

def my_h2():
  return 'my_f2'

def my_h3():
  return 'my_f3'
