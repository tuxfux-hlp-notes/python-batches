#!/usr/bin/python

import logging as l
l.basicConfig(filename='log.txt',format='%(asctime)s - %(levelname)s - %(message)s',datefmt='%b- %c - %p',level=l.DEBUG)
l.debug("this is debug log")
l.info("this is information")
l.warning("this is warnings")
l.error("this is error")
l.critical("this is critical")
