# write a function which can do this activity
# def my_great():
  pass
 
 expectations:
  my_great(4,5) => 5
  my_great(4,5,10,12) => 12
  my_great(1,2,3) => 3
  my_great(1) => pleae pass two numbers
  
hint : *,*args

# write a program to do the following

python my_great 2 3 => 3
python my_great 2 3 4 => 4
python my_great 2  => pleae enter two numbers

hint : arrays
