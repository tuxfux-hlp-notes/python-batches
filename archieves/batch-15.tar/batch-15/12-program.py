#!/usr/bin/python

try:
  num1 = int(raw_input("please enter the number 1:"))
  num2 = int(raw_input("please enter the number 2:"))
  value = num1/num2
except ValueError,error:
  print "please enter numbers only"
except ZeroDivisionError:
  print "please enter your denominator without zero"
else:
  print value
finally:
  print "yes we are done!!"
  print "error hit is %r" %(error)


