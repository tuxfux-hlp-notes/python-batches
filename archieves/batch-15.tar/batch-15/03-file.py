#!/usr/bin/python
# kiosk

print "hello welcome to the market"
type_food = raw_input("please enter the type of food(veg,fish,mutton,chicken):")
if type_food == 'fish':
  my_fish = raw_input("please enter what fish you need(peru,solomon,rohu):")
  if my_fish == 'peru' or my_fish == 'PERU':
    print "we have the peru fish \n"
    print "what is the quantity you need ? \n"
  elif my_fish == 'rohu':
    pass
  elif my_fish == 'solomon':
    pass
  else:
    print "Sorry !!! we don't have your fish type"
    print "please visit our nearest store!!"
elif type_food == 'chicken':
  pass
elif type_food == 'mutton':
  pass
elif type_food == 'veg':
  pass
else:
  pass
  
print "Please come back again !!!! "

# if .. else
# if .. elif .. else
# if
