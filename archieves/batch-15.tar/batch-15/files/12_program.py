#!/usr/bin/python

f = open("file.txt")   # opening this file in ro
# f = open("file.txt","r")
# f = open("file.txt","w")
# f = open("file.txt","a")

# windows space
# .exe,.iso,.jpg,.doc
# binary - b
# f = open("file.txt","rb")
# f = open("file.txt","wb")
# f = open("file.txt","ab")

print f.read()
f.close()

if f.closed :
  print "i have closed the file"
else:
  print "i have not closed the file"
  
# open
# modes
# f.read
# f.readline
# f.readlines
# f.close
# f.closed

# f.write
# f.writelines
# f.flush
