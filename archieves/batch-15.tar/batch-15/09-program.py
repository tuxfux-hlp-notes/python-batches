#!/usr/bin/python

# converted the string into list
word = 'python' # convert python to tython
list_word = list(word)
print list_word
list_word[0] = 'T'
print list_word

# convert the list to string
limiter=''
word = limiter.join(list_word)
print word

# converting a sentence into list
sentence = "Perl is my first language"
list_sen = sentence.split(' ')
print list_sen
list_sen[0] = "Python"
print list_sen
limiter=' '
sentence = limiter.join(list_sen)
print sentence
