#!/usr/bin/python
import pdb

def my_first():
  return "hello"

def my_second(a,b):
  print "values are {},{}".format(a,b)
  a = int(a)
  b = int(b)
  addition = a + b
  if addition > 10:
    return "the output has a value  great than 10"
  else:
    return "the outut has a value less than 10"

pdb.set_trace()
print "welcome to the debugging class"
my_first()
print my_second(10,20)
print my_second(40,50)

