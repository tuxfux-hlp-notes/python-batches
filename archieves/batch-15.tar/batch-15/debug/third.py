#!/usr/bin/python

import pdb

def first():
  second()
  return "i am in function 1"
def second():
  third()
  return "i am in function 2"
def third():
  fourth()
  return "i am in function 3"
def fourth():
  return "i am in function 4"

pdb.set_trace()  
print first()
