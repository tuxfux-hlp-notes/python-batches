#!/usr/bin/python

import pdb
pdb.set_trace()
for i in range(1,30):
  print i
