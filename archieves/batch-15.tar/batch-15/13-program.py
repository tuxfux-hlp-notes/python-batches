#!/usr/bin/python
import logging as l

l.debug("this is debug log")
l.info("this is information")
l.warning("this is warnings")
l.error("this is error")
l.critical("this is critical infomation")

# default : warning
# logging level.
# DEBUG
# INFO
# WARNING
# ERROR
# CRITICAL
