#!/usr/bin/python

words = ['happy','today','sunday','always']

for word in words:
  print word,len(word)
  
for word in words:
  print (word[:(words.index(word) +1)]).upper() + word[(words.index(word) +1):]
