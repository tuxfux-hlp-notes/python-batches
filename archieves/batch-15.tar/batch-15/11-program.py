#!/usr/bin/python

def my_multi(num,default=10):
  for i in range(1,default+1):
    print "%d * %d = %d" %(num,i,num*i)
    
num = int(raw_input("please enter the number"))
my_multi(num)

print "muliplication till 20th"
my_multi(num,default=20)
