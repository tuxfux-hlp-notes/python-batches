#!/usr/bin/python

even=list()
odd=list()
for i in range(1,31):
  if i % 2 == 0:
    even.append(i)
  else:
    odd.append(i)
    
print "odd numbers:" , odd
print "even numbers:" ,even
  
