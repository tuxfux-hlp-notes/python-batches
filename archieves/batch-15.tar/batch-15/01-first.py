#!/usr/bin/python
# Author:
# Usage:
# logs:
# first line is called sha-bang
print "hello world \n"
