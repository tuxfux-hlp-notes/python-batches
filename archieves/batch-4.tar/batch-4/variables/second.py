#!/usr/bin/python
name = raw_input("Please enter your name:")
number = raw_input("Please enter your number:")
print "your name is %s and your number is %s" %(name,number)
raw_input("... please enter some key ... ")
