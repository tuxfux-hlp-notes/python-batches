import logging
logging.basicConfig(filename="mylog.log",format="%(asctime)s - %(levelname)s - %(message)s",datefmt="%a-%b-%Y %T ",level=logging.DEBUG)
diskspace=90
if diskspace > 85 and diskspace < 91:
  logging.warn("You have hit the warning message - disspace %d", diskspace) 
