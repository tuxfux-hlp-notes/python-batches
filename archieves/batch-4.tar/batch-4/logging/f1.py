import logging
logging.basicConfig(filename="mylog.log",format="%(asctime)s - %(levelname)s - %(message)s",datefmt="%a-%b-%Y %T ",level=logging.DEBUG)
logging.debug("This is Debug message")
logging.info("This is an Info message")
logging.warn("This is a warning message")
logging.critical("This is a critical message")
