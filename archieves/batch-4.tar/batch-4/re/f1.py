#!/usr/bin/python
import re
import sys
reg = re.compile("exit",re.I)
status = raw_input("Do you want to continue or exit:")

if reg.match(status):
  print "please exit the program"
  sys.exit()
else:
  print "Please continue with the program"

