#!/usr/bin/python

if __name__ == '__main__':
  print "hello we are in the main program"
else:
  print "we are importing .. "
  version='1.0'
