#!/usr/bin/python
import sys
#import sanmod as sn

print sys.path
#print sn.version
#sn.first_func()



