#!/usr/bin/python

version='3.0'

def first_func():
  ''' hello this is my first function'''
  print "function 1"
