#!/usr/bin/python

def linux_func3():
  print "Hello this is my third function for linux"

def linux_func4():
  print "Hello this is my fourth function for linux"
