#!/usr/bin/python

def linux_func1():
  print "Hello this is my first function for linux"

def linux_func2():
  print "Hello this is my second function for linux"
