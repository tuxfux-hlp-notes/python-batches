#!/usr/bin/python
# autor:
# date:
# log:
# purpose:


print "today is thursday \n"
