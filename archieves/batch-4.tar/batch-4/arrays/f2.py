#!/usr/bin/python


def odd_even(i):
  if i % 2 == 0:
    return 'even'
  else:
    return 'odd'


even_array=list()
odd_array=list()

for i in range(1,11):
  value=odd_even(i)
  if value == 'even':
    even_array.append(i)
  else:
    odd_array.append(i)


print "The list of even numbers is:" , even_array
print "The list of odd numbers is:" , odd_array
