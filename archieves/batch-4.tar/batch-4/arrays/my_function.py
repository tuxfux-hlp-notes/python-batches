#!/usr/bin/python

def number_greater(a,b):
  if a > b:
    print "%d is greater than %d" %(a,b)
  elif b > a:
    print "%d is greater than %d" %(b,a)
  else:
    print "%d and %d are equals" %(a,b)



number_greater(10,20)
number_greater(50,10)
number_greater(10,10)
      
