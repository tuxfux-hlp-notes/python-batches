#!/usr/bin/python
# purpose: understaind the conditions

species = raw_input("plese enter the species name:")

if species == "fish":
  fish = raw_input("Please enter the fish name:")
  print "The species you selected is fish"
  if fish == "peru":
    print "The name of the fish is peru"
  elif fish == "toffu":
    print "The name of the fish is toffu"
  else:
    print "The name of the fish is neither peru or toffu"
else:
    print "The species you selected is not a fish"
