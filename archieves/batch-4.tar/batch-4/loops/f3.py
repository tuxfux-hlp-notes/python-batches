#!/usr/bin/python
import sys

while True:
  tell = raw_input("do you want to continue the game- quit to exit:")
  if tell == 'quit' or tell == 'QUIT':
    break
  if tell == 'exit':
    sys.exit(0)
  print "Please continue the game: \n"

print "hello i have come out of the while loop"
    
