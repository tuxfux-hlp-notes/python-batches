#!/usr/bin/python

number = 7
test = True

while test:
  guess = int(raw_input("please enter the number of your choice:"))

  if guess == number:
    print "Congrats !!! you entered the right number"
    test=False
  elif guess > number:
    print "no, you number is sligtly greater than the number"
  elif guess < number:
    print "no, you number is sligtly lesser than the number"
