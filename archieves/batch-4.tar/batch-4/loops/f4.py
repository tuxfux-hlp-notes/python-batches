#!/usr/bin/python

for i in range(10):
  if i == 0:
    continue
  print " -- %d ---- " %(i)
  if i % 2 == 0:
    print "the %d is divisible by 2 " %(i)
 
