#!/usr/bin/python

item = raw_input("Please enter the type of item(fish/chicken):")

if item == 'fish':
  pass
elif item == 'chicken':
  pass
else:
  pass
  
