#!/usr/bin/python
import sys

number = 7
value = True

while ( value ):
  
  status = raw_input("do you want to continue the game(y/n)")
  if status == 'n':
    sys.exit(0)

  number = int(raw_input("please enter your number:"))
  
  if number == 7:
    print "you the man !!! you have selected right number"
    break
  elif number < 7:
    print "you have given number slightly less"
  elif number > 7:
    print "you have given number slightly more"

print "we have completed the program"
