#!/usr/bin/python

item = raw_input("Please enter the type of item(fish/chicken):")

if item == 'fish':
  print "Hello welcome to the fish market \n"
  fish = raw_input("please enter the fish type:\n(toffu and peru)")
  if fish == 'toffu':
    print "the fish you selected is %s" %(fish)
  if fish == 'peru':
    print "the fish you selected is %s" %(fish)
elif item == 'chicken':
    print "Hello welcome to the chicken market"
    chicken = raw_input("please enter the chicken type:\n(local and village)")
    if chicken == 'local' or chicken == 'village':
      print "The chicken you selected is %s" %(chicken)
    else:
      print "The chicken %s is not there" %(chicken)
else:
  print "Thanks for visiting.."
  print "your item is not with us"

  
