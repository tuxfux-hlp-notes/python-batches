def second():
  print "I am in the second"
