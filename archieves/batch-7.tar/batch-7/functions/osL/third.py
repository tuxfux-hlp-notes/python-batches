def third():
  print "I am in the third"
