def first():
  print "I am in the first"
