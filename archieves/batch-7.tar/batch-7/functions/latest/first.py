#!/usr/bin/python

version='2.0'

def fun_max(a,b):
  ''' syntax: fun_max(a,b) '''
  if a > b:
    print "a is greater"
  else:
    print "b is greater"

if __name__ == '__main__':
  print "I am in the main program"
  fun_max(10,20)
else:
  print "I am imported as module"
