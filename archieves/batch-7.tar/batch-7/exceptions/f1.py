#!/usr/bin/python

try:
  num1 = int(raw_input("please enter number 1:"))
  num2 = int(raw_input("please enter number 2:"))
  print "division of two numbers is %f" %(num1/num2)
except ValueError,error:
  print "Please enter numbers for your inputs"
except ZeroDivisionError,error1:
  print "please set your denominator as non zero"

print "My errors are: \n"
print error
print error1
