#!/usr/bin/env python

num1 = int(raw_input("Please enter a number:"))
num2 = int(raw_input("please enter a number:"))

print "my number1 => %d , my number2 => %d" %(num1,num2)
