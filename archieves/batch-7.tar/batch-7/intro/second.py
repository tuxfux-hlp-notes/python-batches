#!/usr/bin/python
number = 1
number2 = 10
if number > number2:
    print "{} is greater than {}".format(number,number2)
else:
    print "{} is greater than {}".format(number2,number)
    
