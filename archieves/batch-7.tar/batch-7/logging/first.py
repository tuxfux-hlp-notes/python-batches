#!/usr/bin/python
import logging

# debug
# info
# warning
# error
# critical

logging.info("Hello this is an information message")
logging.warning("Hello this is an warning message")
logging.critical("Hello this is an critical message")
