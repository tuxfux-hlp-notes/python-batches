#!/usr/bin/python
import logging as lg


lg.basicConfig(filename="second.log",filemode='a',datefmt='%b %d %T',format='%(asctime)s - %(levelname)s - %(message)s',level=lg.INFO)
lg.info("Hello this is information")
lg.warning("Hello this is warning")
