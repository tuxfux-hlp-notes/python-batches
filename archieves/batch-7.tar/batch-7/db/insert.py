#!/usr/bin/python
import MySQLdb as mdb
con = mdb.connect('localhost','newuser','newuser','new_db')
cur = con.cursor()
cur.executemany("insert into students(rollno,name) values (%s,%s)",[(1,'hari'),(2,'priya'),(3,'vicky')])
con.commit()
