#!/usr/bin/python
value="g fmnc wms bgblr rpylqjyrc gr zw fylb. rfyrq ufyr amknsrcpq ypc dmp. bmgle gr gl zw fylb gq glcddgagclr ylb rfyr'q ufw rfgq rcvr gq qm jmle. sqgle qrpgle.kyicrpylq() gq pcamkkclbcb. lmu ynnjw ml rfc spj."
import string
alp = list(string.letters[0:26])
latest=list()
limiter=''

for i in value:
  if i in alp:
    newvalue=(alp.index(i) + 2)
    if newvalue == 26:
      newvalue=0
    elif newvalue == 27:
      newvalue=1
    latest.append(alp[newvalue])
  else:
    latest.append(i)
  i=''

print limiter.join(latest)


