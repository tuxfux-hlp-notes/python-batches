#!/usr/bin/python
student=dict()
for i in range(1,5):
  key1 = raw_input("Please enter the name of the student:")
  value1 = int(raw_input("please enter the marks:"))
  student[key1]=value1

print student
