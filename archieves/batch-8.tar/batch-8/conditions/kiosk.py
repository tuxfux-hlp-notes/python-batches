#!/usr/bin/python

item = raw_input("Please enter the item(fish,chicken)")
if item == 'fish':
  fish_type = raw_input("please enter the fish type(solomon,peru,toffu)")
  if fish_type == 'peru':
    print "The fish type %s is present" %(fish_type)
  elif fish_type == 'solomon':
    print "The fish type %s is present" %(fish_type)
  else:
    print "sorry!! we don't have fish of your type %s" %(fish_type)
elif item == 'chicken':
  chic_type = raw_input("please enter the chicken type(boiler,local)")
  if chic_type == 'boiler':
    print "the chicken type %s is present" %(chic_type)
  elif chic_type == 'local':
    print "the chicken type %s is present" %(chic_type)
  else:
    print "sorry !! we don't have chicken of your type %s" %(chic_type)
else:
  print "sorry!! we don't have the item %s" %(item)

