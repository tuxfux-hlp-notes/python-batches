#!/usr/bin/python

num1 = int(raw_input("Please enter the number 1:"))
num2 = int(raw_input("Please enter the number 2:"))
num3 = int(raw_input("Please enter the number 3:"))

if num1 > num2 and num1 > num3:
  print "%d is the greatest" %(num1)
elif num2 > num1 and num2 > num3:
    print "%d is the greatest" %(num2)
elif num3 > num2 and num3 > num1:
  print "%d is the greatest" %(num3)
else:
    print "%d,%d,%d all are equal" %(num1,num2,num3)
    print "program over"
