#!/usr/bin/python
import sys

number = 7
test = True

quit = raw_input("Do you want to continue:(y/n)")
if quit == 'n':
  sys.exit()

while test:
  choice = int(raw_input("Please enter a number:"))
  if choice == number:
    print "Congratulation !!! you have chosen the right number"
    break
    #test=False
  elif choice < number:
    print "you have chosen the number slight lesser.Please try again."
  elif choice > number:
    print "you have chosen the number slightly greater. Please try again"


print "I have completed my game!!! Let me go home"
