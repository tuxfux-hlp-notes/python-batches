#!/usr/bin/python


def func_add(num1,num2):
  ''' we are using this for addition '''
  print "Addition of two numbers: %d" %(num1 + num2)
  
def func_mul(num1,num2=30):
  ''' we are using this for multiplication '''
  return (num1 * num2)

def func_mod(num1,num2):
  ''' we are using this for modules '''
  return (num1 % num2)

while True:
  exit = raw_input("do you want to continue(y/n):")
  if exit == 'n':
    break
  num1 = int(raw_input("please enter the number1:"))
  num2 = int(raw_input("please enter the number2:"))

  value = int(raw_input("""
  1. Addition
  2. Multiplication
  3. Modules
  """))

  if value == 1:
    func_add(num1,num2)
  elif value == 2:
    if num2 < 10:
      func_mul(num1)
    else:
      func_mul(num1,num2)
    fi
    #output=func_mul(num1,num2)
    #if func_mod(func_mul(num1,num2),2) == 0:
    #  print "even number"
    #else:
    #  print "odd number"
    #func_mul(num1)
  else:
    func_mod(num1,num2)


