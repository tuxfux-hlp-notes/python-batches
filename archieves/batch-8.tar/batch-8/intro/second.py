#!/usr/bin/python

num1 = 10
num2 = 20
if num1 > num2 :
    print "{} is greater than {}".format(num1,num2)
else:
    print "{} is greater than {}".format(num2,num1)


