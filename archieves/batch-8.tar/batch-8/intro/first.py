#!/usr/bin/python

print "hello today is friday"
