#!/usr/bin/python

def lin_func1():
  return "lin_func1"
def lin_func2():
  return "lin_func2"
