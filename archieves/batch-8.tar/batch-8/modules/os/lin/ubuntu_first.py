#!/usr/bin/python

def ubuntu_func1():
  return "ubuntu_func1"
def ubuntu_func2():
  return "ubuntu_func2"
