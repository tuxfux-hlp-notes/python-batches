#!/usr/bin/python

import sys
sys.path.append('/home/visitor/python-examples/batch-8/modules/mod')
import first

a = int(raw_input("Please enter the value 1:"))
b = int(raw_input("Please enter the value 2:"))

print first.my_add(a,b)
