#!/usr/bin/python

my_version='2.0'
def my_function():
  ''' This is my_function to print hello'''
  print "Hello this is my function"

def my_add(a,b):
  ''' This is my_add function to add values '''
  return a+b

if __name__ == '__main__':
  print my_function()
  print my_add(30,40)
else:
  print "I am now working as module"
