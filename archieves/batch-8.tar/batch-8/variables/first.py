#!/usr/bin/python

string = raw_input("Please enter the name:")

print "Upper case of our string is:%s" %(string.upper())
print "Lower case of our string is:%s" %(string.lower())
print string.center(30,'*')
