#!/usr/bin/python
import logging as l
l.basicConfig(filename='log.txt',format='%(asctime)s - %(levelname)s - %(message)s',level=l.DEBUG,datefmt='%F - %r')

disk = int(raw_input("please enter the disk size"))
if disk < 30 and disk > 0:
  l.info("We have a functioning disk")
elif disk > 30 and disk < 50:
  l.debug("we have a functioning disk")
elif disk > 50 and disk < 70:
  l.warning("disk is about to reach threshold")
elif disk > 70 and disk < 90:
  l.error("Please check the size of your disk")
elif disk > 90:
  l.critical("The disk is gone")


