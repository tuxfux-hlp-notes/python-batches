#!/usr/bin/python
import logging as l
l.info("hello this is information")
l.debug("Hello this is debug information")
l.warning("Hello this is warning information")
l.critical("Hello this is critical information")
l.error("Hello this is error information")

