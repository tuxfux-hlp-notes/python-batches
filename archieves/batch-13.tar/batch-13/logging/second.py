#!/usr/bin/python
import logging as l
l.basicConfig(filename='log.txt',format='%(asctime)s - %(levelname)s - %(message)s',level=l.DEBUG,datefmt='%F - %r')
l.info("hello this is information")
l.debug("Hello this is debug information")
l.warning("Hello this is warning information")
l.critical("Hello this is critical information")
l.error("Hello this is error information")


