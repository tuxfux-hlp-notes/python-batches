#!/usr/bin/python
import sys
sys.path.append('/home/visitor/python-examples/batch-12/modules')
import first
print "Santosh,please greet every one"
first.my_hello()

