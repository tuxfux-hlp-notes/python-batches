#!/usr/bin/python

name = raw_input("please enter you name:")
age = int(raw_input("please enter your age:"))
gender = raw_input("please enter your gender:")  # synonym to sex.

'''
print "name:%s , age:%d , gender:%s" %(name,age,gender)
raw_input("... press any key to exit ...")
'''
