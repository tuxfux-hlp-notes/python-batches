#!/usr/bin/env python
print "Hello today is thursday"
