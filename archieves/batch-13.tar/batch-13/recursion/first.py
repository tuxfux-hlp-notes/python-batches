#!/usr/bin/python

for value in range(1,11):
  print value

for value in ('mon','tue','wed','thu'):
  print value

for value in 'python':
  print value
