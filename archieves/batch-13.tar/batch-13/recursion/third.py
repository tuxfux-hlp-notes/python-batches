#!/usr/bin/python
# binary to numeric convertion
# 1111 -> 15

num = raw_input("please enter the binary digit:")
i = 0
total = 0
for value in num[::-1]:
  total = total + (int(value) * 2**i )
  i = i + 1 

print "the binary conversion for %s is %d" %(num,total)

