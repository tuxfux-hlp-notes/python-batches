#!/usr/bin/python

import sys
number=7
test=True

yn = raw_input("do you want to continue with the game:")
if yn == 'yes':
  while test:
    num = int(raw_input("please enter the number you think is lucky:"))
    if num > number:
      print "you took a number slightly larger"
    elif num < number:
      print "you took a number slightly smaller"
    elif num == number:
      print "congrats !! you chose the right number"
      break
else:
  sys.exit()

print "Thanks for playing the game. Please visit us again !!!"
