#!/usr/bin/python
num=1
num1=1
num2=1

if num > num1 and num > num2:
  print "%d is greater" %num
elif num2 > num1 and num2 > num:
  print "%d is greater" %num2
elif num1 > num and num1 > num2:
  print "%d is greater" %num1
else:
  print "all numbers are equal"
  print "%d %d %d are the numbers" %(num,num1,num2)
