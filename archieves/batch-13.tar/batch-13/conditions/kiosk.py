#!/usr/bin/python
print "welcome to the fish market"
type = raw_input("do you want fish/chicken/mutton:")
if type == 'fish':
  fish_type=raw_input("do you want toffu,peru,solomon:")
  if fish_type == 'toffu' or fish_type == 'Toffu':
    print "yes we have the fish type %s" %(fish_type)
    print "what is the quantity you need"
    print "please visit us again"
  elif fish_type == 'peru' or fish_type == 'Peru':
    print "yes we have the fish type %s" %(fish_type)
    print "what is the quantity you need"
    print "please visit us again"
  else:
    print "we dont have the %s fish type" %(fish_type)
    print "please visit us again"
elif type == 'chicken':
  pass
elif type == 'mutton':
  pass
