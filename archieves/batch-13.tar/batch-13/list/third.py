#!/usr/bin/python
Words=['today','tomorrow','dayafter']
#first task
#'today' 5
#'tomorrow' 8
#hints: len
for i in Words:
  print i,len(i)

# second task
#'Today'
#'TOmorrow'
#'DAYafter'
# hints: slicing
for i in Words:
  print (i[:(Words.index(i)+1)]).upper() + i[(Words.index(i)+1):]
