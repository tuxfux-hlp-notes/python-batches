#!/usr/bin/python
# range(1,21)
# {'1':'1','2':4'.......'9':'81'}

dval=dict()
for i in range(1,21):
  dval[i]=i*i

print dval
