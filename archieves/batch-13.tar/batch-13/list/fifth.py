input the values 1,2,3,4,5,6 as the console input.
get the output as
(1,2,3,4,5,6)
[1,2,3,4,5,6]
