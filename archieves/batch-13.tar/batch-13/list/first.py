#!/usr/bin/python
name = raw_input("please enter the string name:")
Nname = list(name)
print Nname
Nname.reverse()
limiter=''
print limiter.join(Nname)
