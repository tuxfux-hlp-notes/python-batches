#!/usr/bin/python
odd=list()
even=list()
for i in range(1,21):
  if i % 2 !=0:
    odd.append(i)
  else:
    even.append(i)

print "value of odd:" , odd
print "value of even:" , even
