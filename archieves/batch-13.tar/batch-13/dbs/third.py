#!/usr/bin/python
import MySQLdb as mdb
con = mdb.connect('localhost','test_user1','test_user1','my_data')
cur = con.cursor()
roll_no=int(raw_input("please enter your rollno:"))
Name=raw_input("please enter your name:")
cur.execute("insert into students(rollno,name) values (%s,%s)",(roll_no,Name))
con.commit()


