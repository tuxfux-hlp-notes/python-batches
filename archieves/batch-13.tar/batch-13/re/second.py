#!/usr/bin/python
import re

f = open("file2.txt","rb")
string_f=f.read()
reg=re.compile('^[a-z0-9._]+@[a-z.]+',re.MULTILINE)
print reg.findall(string_f)
f.close()
