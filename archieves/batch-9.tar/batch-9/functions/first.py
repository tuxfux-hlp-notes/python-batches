#!/usr/bin/python

def my_vowel(char):
  ''' vowels means - a,e,i,o,u.
  remaining alphabets represtent - consonant'''

  if char in ('a','e','i','o','u'):
    return "vowel"
  else:
    return "consonant"


# Main program

print "The function my_vowel usage is", my_vowel.func_doc
char = raw_input("please enter a string-character:")
value = my_vowel(char)
print "The %s is %s" %(char,value)
  
  
