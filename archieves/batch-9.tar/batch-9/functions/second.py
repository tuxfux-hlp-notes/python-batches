#!/usr/bin/python

def my_mult(num,value=10):
  for i in range(1,value+1):
    print "%d * %d = %d" %(num,i,num*i)

# main

num = int(raw_input("Please enter the number"))
my_mult(num)
my_mult(num,value=20)
