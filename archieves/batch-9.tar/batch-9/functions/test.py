#!/usr/bin/python

def my_vowel(char):
  ''' vowels means - a,e,i,o,u.
  remaining alphabets represtent - consonant'''

  if char in ('a','e','i','o','u'):
    return "vowel"
  else:
    return "consonant"

