#!/usr/bin/python

first = raw_input("Please enter the name:")
second = raw_input("Please enter the second name:")
print "my name is %s %s" %(first,second)
