#!/usr/bin/python

sentence = raw_input("Please enter the sentence:")
print "my sentence is : %s" %(sentence)

# convent the sentence to list of wordss.

L_words = sentence.split(' ')
print L_words

if 'Today' in L_words:
  L_words[L_words.index['Today']] = 'Tomorrow'

# Join the words into sentences

limiter=' '
print "my latest word is:%s" %(limiter.join(L_words))
