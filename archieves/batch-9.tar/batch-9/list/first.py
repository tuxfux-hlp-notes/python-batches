#!/usr/bin/python


# python -> Tython

name = raw_input("please enter a string:")
print name

# string to list

L_name = list(name)

if 'p' in L_name:
  L_name[0]='T'

print L_name

# list to a string

limiter=''
print limiter.join(L_name)
