#!/usr/bin/python
'''
print "hello world !11"
name = raw_input("Please enter your name:")
print type(name)
number = int(raw_input("Please enter your number:"))
print type(number)
print "name:" , name
print "number:" , number
print "My name is %s and my number is %d" %(name,number)
'''

# input

number = input("please enter your number")
print type(number)
print "number:%d" %(number)
name = str(input("please enter your name"))
print type(name)
print "name:%s" %(name)

