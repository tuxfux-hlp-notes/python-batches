#!/usr/bin/python
import sys

number = 7
test = True

exit = raw_input("Do you want to exit the game:")
if exit == 'n' or exit == 'N':
  while test:
    num = int(raw_input("please enter a number:"))
    if num == number:
      print "CONGO !!! you have won"
      break
      #test = False
    elif num > number:
      print "you have selected the number slight big"
    elif num < number:
      print "you have selected the number slight small"
    else:
      print "test"
else:
     sys.exit()

print "Thanks for playing the game"
