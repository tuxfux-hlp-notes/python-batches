#!/usr/bin/python

non_type = raw_input("Please enter the name - fish/chicken:")

if non_type == "fish":
  fish_type = raw_input("Please enter the kind of fish(toffu,peru):")
  if fish_type == "toffu" or fish_type == "Toffu":
    print "Hello the fish you chose is toffu"
    print "Please visit again!!"
  elif fish_type == "peru" or fish_type == "Peru":
    print "Hello the fish you chose is peru"
    print "please visit again!!"
  else:
    print "sorry!! we are out of stock !!!"
    print "please visit again !!! "
elif non_type == "chicken":
  print "please take the chicken"
  print "Please visit us again !!!"
else:
  print "sorry!!! we dont have the type %s" %(non_type)
  print "Please visit us again !!!"
