#!/usr/bin/python
import logging as l
l.basicConfig(filename='my_app.log',format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',datefmt='%b %d %r',level=l.DEBUG)
l.debug("Hello this is a debug information")
l.info("hello this is just information")
l.warning("Hello i am trying to warn you")
l.error("Hello this is error")
l.critical("Hello our app is down")
