#!/usr/bin/python

try:
  num1 = int(raw_input("please enter the number:"))
  num2 = int(raw_input("please enter the number:"))
except ValueError,error:
  print "please enter numbers only !!! "

print "The error is %s"  %(error)

#try:
#except NameError:
#  print "Please enter valid values"
