#!/usr/bin/python

import sys
sys.path.append('/home/visitor/python-examples/batch-9/modules/mod')
import first as f
print f.version
first = int(raw_input("please enter a number"))
second = int(raw_input("please enter second number"))
result = f.my_add(first,second)
print "The addition of %d and %d is %d" %(first,second,result)


