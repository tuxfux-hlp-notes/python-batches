#!/usr/bin/python

def third():
  return "I am in lin_third project"
