#!/usr/bin/python

def first():
  return "I am in lin_first project"
