#!/usr/bin/python

def fourth():
  return "I am in lin_fourth project"
