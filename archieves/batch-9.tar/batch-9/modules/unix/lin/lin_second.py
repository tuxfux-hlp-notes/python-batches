#!/usr/bin/python

def second():
  return "I am in lin_second project"
