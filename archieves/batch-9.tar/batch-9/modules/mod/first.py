#!/usr/bin/python

version='1.0'
def my_add(a,b):
  ''' Addition of two numbers
  syntax: s.my_add(a,b)
  (a,b) => values
  '''
  return a + b

if __name__ == '__main__':
  print "I am doing addition"
  print my_add(10,10)
