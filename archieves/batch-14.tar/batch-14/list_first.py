#!/usr/bin/python
parrot=['the','dead','parrot','sketch']
for i in parrot:
  print i.capitalize(),len(i)

for i in parrot:
  print i[0:(parrot.index(i) + 1)].upper() + i[(parrot.index(i) + 1 ):]
  #print "%s,%d" %(i,parrot.index(i))
