#!/usr/bin/env python
# sha-bang,hash-bang
print "hello world !! \n"
