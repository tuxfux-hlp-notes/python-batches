#!/usr/bin/python
# conditions
# truth of a statement

print "welcome to the market"
my_type = raw_input("please enter the type(fish,chicken,mutton):")
if my_type == 'fish' or my_type == 'FISH':
  print "we have the fish in the market"
  fish_type = raw_input("please enter the type of fish(peru,solomon,toffu):")
  if fish_type == 'peru' or fish_type == 'solomon' or fish_type == 'toffu':
    print "we have the fish type"
  else:
    print "we don't have the fish type"
elif my_type == 'chicken' or my_type == 'CHICKEN':
  print "we have the chicken in the market"
elif my_type == 'mutton' or my_type == 'MUTTON':
  pass
else:
  pass
