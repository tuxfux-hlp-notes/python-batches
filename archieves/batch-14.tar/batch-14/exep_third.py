#!/usr/bin/python

try:
  number = int(raw_input("please enter your number:"))
except ValueError:
  print "please enter the number"
else:
  print "my name is:" , number
