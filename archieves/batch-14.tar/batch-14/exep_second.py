#!/usr/bin/python
import sys

try:
  num1 = int(raw_input("please enter a number 1:"))
  num2 = int(raw_input("please enter a number 2:"))
except ValueError:
  print "please enter numbers only"
  sys.exit()

try:
  print num1/num2
except ZeroDivisionError:
  print "Dont enter denominator as zero"
