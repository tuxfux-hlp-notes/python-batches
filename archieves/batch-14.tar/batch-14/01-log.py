#!/usr/bin/python

import logging as l
# level = WARNING

l.debug("hello thi is a debugging message")
l.info("hello this is a information message")
l.warning("hello this is an warning message")
l.error("hello this is an error message")
l.critical("hello this is an critical message")

