#!/usr/bin/python

def first():
	return "first"

def second():
	return "second"

def third():
	return "third" 
