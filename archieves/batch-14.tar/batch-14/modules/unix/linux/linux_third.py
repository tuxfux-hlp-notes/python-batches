#!/usr/bin/python

def our_first():
	return "first"

def our_second():
	return "second"

def our_third():
	return "third"
