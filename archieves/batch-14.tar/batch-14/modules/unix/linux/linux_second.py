#!/usr/bin/python

def my_first():
	return "my_first"

def my_second():
	return "my_second"

def my_third():
	return "my_third"
