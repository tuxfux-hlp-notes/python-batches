#!/usr/bin/python
import sys
sys.path.append('/home/tcloudost/python-examples/batch-14/modules')
import first as f
print " i am trying to add two strings"
str_1 = "santosh"
str_2 = " kumar"
print f.my_add(str_1,str_2)
