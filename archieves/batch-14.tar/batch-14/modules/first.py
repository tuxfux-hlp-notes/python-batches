#!/usr/bin/python

version='2.0'

def my_first():
	''' This is my first program. '''
	return 'hello'

def my_add(a,b):
	''' Addition of two numbers. 
	    syntax:my_add(a,b)	'''
	sum = a + b
	return sum

if __name__ == '__main__':
	print "hello i am trying to test my program"
	print version
	print my_first()
	print my_add(20,30)
