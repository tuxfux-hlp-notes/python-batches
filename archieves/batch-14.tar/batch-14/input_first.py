#!/usr/bin/env python
name = raw_input("please enter the name:")
roll_no = int(raw_input("please enter the roll number:"))
print "my name is %s.My roll number is %d" %(name,roll_no)

