#!/usr/bin/python
import re
reg = re.compile('yes',re.I)

answer = raw_input("do you want to continue the game:")
if reg.match(answer):
  print "i want to play the game"
else:
  print "i dont want to play the game"

