#!/usr/bin/python
# for,while

for value in 'python':
  print value

# tuple of values

for value in ('python','perl','linux','django'):
  print value

#print your name 5 times
for i in range(1,11):
  if i == 3:
    continue
  print "%d ,santosh" %(i)
