#!/usr/bin/python
#basicConfig
import logging as l
# config for basic config
l.basicConfig(filename='02-log.txt',format='%(asctime)s - %(levelname)s - %(message)s',datefmt='%F %r',level=l.DEBUG)

# debug messages

l.debug("hello thi is a debugging message")
l.info("hello this is a information message")
l.warning("hello this is an warning message")
l.error("hello this is an error message")
l.critical("hello this is an critical message")


