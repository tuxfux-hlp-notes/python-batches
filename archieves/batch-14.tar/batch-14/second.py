#!/usr/bin/python
# sha-bang,hash-bang
print "hello world !! \n"
