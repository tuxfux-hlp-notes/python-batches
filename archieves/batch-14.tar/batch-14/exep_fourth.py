#!/usr/bin/python

try:
  number1 = int(raw_input("please enter your number1:"))
  number2 = int(raw_input("please enter your number2:"))
except ValueError,error:
  print "please enter the number"
  print "my exception error is %s" %(error)
else:
  print "my numbers are:%d,%d" %(number1,number2)
  print number1/number2
finally:
  print "We are done with the program"
