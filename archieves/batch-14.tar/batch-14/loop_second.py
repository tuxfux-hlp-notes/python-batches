#!/usr/bin/python
#while
# Assignment : reduce the number of iterations to 3.
import sys

number=7
test=True

play = raw_input("do you want to play the game(y/n):")
if play == 'n':
  sys.exit(1)

while test:
  guess = int(raw_input("please enter a number:"))
  if guess > number:
    print "Hello!!! the guess is slightly larger"
  elif guess < number:
    print "Hello!!! the guess is slightly smaller"
  elif guess == number:
    print "the guess is correct" 
    #test=False
    break


print "Thanks for playing the game!!!"
