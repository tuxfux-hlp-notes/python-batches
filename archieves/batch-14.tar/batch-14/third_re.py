#!/usr/bin/python

import re
reg = re.compile('[a-z.]+@[a-z]+[.][a-z.]+')

f = open('emails.txt','r')
my_string = f.read()
print reg.findall(my_string)

