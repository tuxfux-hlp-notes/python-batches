#!/usr/bin/python
import re

answer = raw_input("do you want to continue the game:")
if re.match('yes',answer,re.I):
  print "i want to play the game"
else:
  print "i dont want to play the game"

