#!/usr/bin/python

try:
  num1 = int(raw_input("please enter a number 1:"))
  num2 = int(raw_input("please enter a number 2:"))
  print num1/num2
except (NameError,ValueError):
  print "please enter numbers only"
except ZeroDivisionError:
  print "Dont enter denominator as zero"
