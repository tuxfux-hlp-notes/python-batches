#!/usr/bin/python

my_type = raw_input("Do you want veg or fruits:")
if my_type == "veg":
  print "welcome to the veg market"
  my_veg = raw_input("plese enter the veg type:(carrot,radish,turnip)")
  if my_veg == "carrot" or my_veg == "Carrot":
    print "we have carrot in the market"
    print "how many kgs of carrot you need"
    print "thanks for shopping with us"
  else:
    print "we dont have carrots in the market"
    print "thanks for shopping with us"
    print "please visiti us again"
elif my_type == "fruit":
  pass
