#!/usr/bin/python
my_list = ["the","dead","parrot","sketch"]
for i in my_list:
  print i.capitalize(),len(i)

for i in my_list:
  count = my_list.index(i)
  i = i[:count+1].upper() + i[count+1:]
  print i
