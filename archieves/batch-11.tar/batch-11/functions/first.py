#!/usr/bin/python

def my_validate(var):
  if var.isupper() == True:
    print "the word you enter is upper case"
    print "we are going to convert it to lower case"
    print var.lower()

var = raw_input("please enter the variable name:")
my_validate(var)
var1 = raw_input("please enter the variable name:")
my_validate(var1)
