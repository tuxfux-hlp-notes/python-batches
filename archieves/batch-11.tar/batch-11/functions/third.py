#!/usr/bin/python

def my_even(number):
  ''' This is a function to find the even numbers'''
  if value % 2 == 0:
    return 'even'
  else:
    return 'odd'

# main
value = int(raw_input("please enter the value:"))
output = my_even(number=value)
if output == 'even':
  print "Its a even number"
else:
  print "its a odd number"
  
