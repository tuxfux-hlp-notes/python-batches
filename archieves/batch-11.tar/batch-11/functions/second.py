#!/usr/bin/python
# default argument values.
# keyword arguments
def my_multi(a,default=10):
  for i in range(1,(default+1)):
    print "%d * %i = %d" %(num,i,num*i)

num = int(raw_input("please enter the number"))
my_multi(default=20,a=num)
