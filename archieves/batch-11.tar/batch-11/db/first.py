#!/usr/bin/python
import MySQLdb as mdb
con = mdb.connect('localhost','my_user','my_user','my')
cur = con.cursor()
cur.execute("insert into my_student values ('1','santosh')")
con.commit()
#username = cur.fetchone()
#print username
