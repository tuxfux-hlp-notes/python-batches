#!/usr/bin/python
import sys
print "my script name is :" ,sys.argv[0]
my_first = int(sys.argv[1])
my_second = int(sys.argv[2])
print "addition: %d" %(my_first + my_second)
