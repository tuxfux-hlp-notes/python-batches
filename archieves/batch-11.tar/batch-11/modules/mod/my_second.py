#!/usr/bin/python
import sys
sys.path.append('/home/visitor/python-examples/batch-11/modules/')
import my_first as f
f.my_multi(30)
