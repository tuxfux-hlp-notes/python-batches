#!/usr/bin/python
# default argument values.
# keyword arguments
version='2.0'
def my_multi(a,default=10):
  ''' syntax: my_multi(num,[default=10]) ..put any other
      number for range '''
  for i in range(1,(default+1)):
    print "%d * %i = %d" %(a,i,a*i)

def my_add(a,b):
  ''' my_add(a,b) to get sum '''
  addition = a + b
  return addition

if __name__ == '__main__':
  num = int(raw_input("please enter the number"))
  my_multi(default=20,a=num)
