#!/usr/bin/python

students = ['sai','anil','rajesh']
shifts = ['afternoon','morning','evening']

print "before sorts:"
print "student names" , students
print "shifts" , shifts
print "after sorts:"
print students.sort()
#print students
print "student names" , students
print "shifts" , shifts

name = raw_input("please enter the name of the candidate:")
if students[0] == name:
  print "shift is: %s" %(shifts[0])
elif students[1] == name:
  print "shift is: %s" %(shifts[1])
elif students[2] == name:
  print "shift is:%s" %(shifts[2])

