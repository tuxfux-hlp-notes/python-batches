#!/usr/bin/python

a = int(raw_input("please enter the number:"))
b = int(raw_input("please enter the number:"))

if b == 0:
  raise ZeroDivisionError,"Go meet you maths teacher again"
