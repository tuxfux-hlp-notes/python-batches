#!/usr/bin/python

try:
  a = int(raw_input("please enter the number:"))
  b = int(raw_input("please enter the number:"))
  print a/b
except ValueError,error:
  print "please enter only the numbers or integers"
  print "error is {}".format(error)
except ZeroDivisionError,error:
  print "Please enter the denominator greater than zero"
  print "error is {}".format(error)
