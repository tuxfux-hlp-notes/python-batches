#!/usr/bin/python

try:
  a = int(raw_input("please enter the number:"))
  b = int(raw_input("please enter the number:"))
except ValueError,error:
  print "please enter only the numbers or integers"
  print "error is {}".format(error)
else:
  print a/b
finally:
  print "Hello i am out of the program"
