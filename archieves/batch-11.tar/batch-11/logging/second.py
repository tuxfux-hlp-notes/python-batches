#!/usr/bin/python
import logging as l

l.basicConfig(filename='my_log.txt',format='%(asctime)s - %(levelname)s - %(message)s ',datefmt ='%b %d %r',level=l.DEBUG)
l.debug("This is an debug information")
l.info("This is an information")
l.warning("This is an warning")
l.error("this is an error")
l.critical("This is an critical information")

