#!/usr/bin/python
import logging as l

size=int(raw_input("size of the disk:"))
l.basicConfig(filename='my_log.txt',format='%(asctime)s - %(levelname)s - %(message)s ',datefmt ='%b %d %r',level=l.DEBUG)
if size > 70 and size < 80:
  l.warning("Our disk size is between 70 to 80 percentage")
elif size > 80 and size < 90:
  l.error("Disk is betwen 80 and 90 %")
else:
  l.critical("Disk has hit 90%")

