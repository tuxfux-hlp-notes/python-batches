#!/usr/bin/env python
# #, is called as sha
# !, bang

print "Today is python class"
