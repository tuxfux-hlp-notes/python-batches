print "Today is python class"
