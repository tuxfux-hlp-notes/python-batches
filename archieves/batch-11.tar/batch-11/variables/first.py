#!/usr/bin/python
# #, is called as sha
# !, bang

print "Today is python class"
