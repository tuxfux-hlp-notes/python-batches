#!/usr/bin/env python
#Author:
#Date:
#Log:

num1 = int(raw_input("please enter the number1:"))
num2 = int(raw_input("please enter the number2:"))

print "Addition of two number is %d" %(num1 + num2)
