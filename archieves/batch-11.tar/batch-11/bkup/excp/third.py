#!/usr/bin/python

answer = raw_input("please enter the string:(^a)")
if answer == 'a':
  raise NameError,"Buddy.. please dont enter a!!"
else:
  print answer
