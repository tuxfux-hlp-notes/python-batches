#/usr/bin/python

try:
  num1 = int(raw_input("please enter number 1:"))
  num2 = int(raw_input("please enter number 2:"))
except ValueError,error:
  print "Please enter the numbers"
  print "exception error:{}".format(error)
else:
  print num1/num2
finally:
  print "I am running what ever be the case"
