#/usr/bin/python

try:
  num1 = int(raw_input("please enter number 1:"))
  num2 = int(raw_input("please enter number 2:"))
  print num1/num2
except ValueError,error:
  print "Please enter the numbers"
  print "exception error:{}".format(error)
except ZeroDivisionError,error1:
  print "please enter your denominator as number other than zero"
  print "exception error:{}".format(error1)

