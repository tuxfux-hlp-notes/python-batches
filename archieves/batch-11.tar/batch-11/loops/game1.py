#!/usr/bin/env python
import sys

#test = True
number = 7
exit = raw_input("do you want to continue or exit the game")
if exit == 'y':
  while True:
    ques = int(raw_input("please enter the number"))
    
    if ques > number:
      print "The number you chose is slightly larger"
    elif ques < number:
      print "The number you chose is slightly smaller"
    else:
      print "congo !!! you chose the right number"
      break
else:
  sys.exit()

print "Thanks for visiting the game !!! please visit again \n"
