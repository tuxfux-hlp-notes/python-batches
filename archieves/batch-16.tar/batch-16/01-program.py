#!/usr/bin/python
# hash - sha
# ! - bang
# shabang
print "hello world"
