#!/usr/bin/python

# key and values
# list of tuples [(),(),()]
# {},dict()
# {'vardan':'chemistry','shiva':'math','chaitan':'physics'}
