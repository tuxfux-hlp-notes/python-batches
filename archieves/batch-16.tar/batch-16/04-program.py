#!/usr/bin/python

num1 = int(raw_input("please enter number:"))
num2 = int(raw_input("please enter number:"))
num3 = int(raw_input("please enter number:"))

if num1 > num2 and num1 > num3:
  print "%d is the greatest number" %(num1)
elif num2 > num3 and num2 > num1:
  print "%d is the greatest number" %(num2)
elif num3 > num2 and num3 > num1:
  print "%d is the greatest number" %(num3)
else:
  print "all num equal" 
