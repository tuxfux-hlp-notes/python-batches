#!/usr/bin/python
# kiosk

print "welcome to the market"
type = raw_input("what do you want(veg,chicken,fish)?")
if type == 'fish':
  print "welcome to the fish market"
  fish_type = raw_input("what fish you want(peru,rohu,solomon)?")
  if fish_type == 'peru' or fish_type == 'Peru':
    print "we have peru"
    print "what is the quantity you need"
  elif fish_type == 'rohu' or fish_type == 'Rohu':
    print "we have rohu"
    print "what is the quantity you need"
  else:
    print "sorry we dont have your fish type"
    print "hey !! we have chicken too .. want to try "
elif type == 'chicken':
  pass
elif type == 'veg':
  pass
else:
  pass
