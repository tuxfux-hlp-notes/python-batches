#!/usr/bin/python

for i in 'python':
	print i

for i in ('python','perl','shell','django','ruby'):
	print i
	
for i in range(1,11):
	if i == 5:
		continue
	print i