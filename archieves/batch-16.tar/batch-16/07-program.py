#!/usr/bin/python
my_list = ['today','tomorrow','dayafter','weekend']

for names in my_list:
  print names,len(names)
  
for names in my_list:
  print names[:my_list.index(names)+1].upper() + names[my_list.index(names)+1:]
