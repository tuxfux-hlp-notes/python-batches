#!/usr/bin/python

def my_multi(num,default=10):
  for value in range(1,default+1):
    print "%d * %d = %d" %(num,value,num*value)

#my_multi(2)  
#my_multi(2,20)
my_multi(default=20,num=4)
