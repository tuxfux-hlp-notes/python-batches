#!/usr/bin/python
def linux_f1():
  return "linux_first"
def linux_f2():
  return "linux second"
def linux_f3():
  return "linux three"
