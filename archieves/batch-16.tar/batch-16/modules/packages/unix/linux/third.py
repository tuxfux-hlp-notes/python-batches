#!/usr/bin/python
def linux_h1():
  return "linux_first"
def linux_h2():
  return "linux second"
def linux_h3():
  return "linux three"
