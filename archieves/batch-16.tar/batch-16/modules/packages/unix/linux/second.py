#!/usr/bin/python
def linux_g1():
  return "linux_first"
def linux_g2():
  return "linux second"
def linux_g3():
  return "linux three"
