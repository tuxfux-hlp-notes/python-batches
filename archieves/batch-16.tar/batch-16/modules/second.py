#!/usr/bin/python
import sys
sys.path.append('/home/tcloudost/python-examples/batch-16/modules/extra')
from first import my_add
print "addition of two numbers:%d" %(my_add(1,2))
