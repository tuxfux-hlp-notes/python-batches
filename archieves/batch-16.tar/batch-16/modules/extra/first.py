#!/usr/bin/python

version='3.0'

def my_add(a,b):
  ''' This is for addition '''
  return a + b

def my_sub(a,b):
  """ This is for substarctions """
  return a-b
  
def my_div(a,b):
  return a/b
  
def my_mul(a,b):
  return a*b

if __name__ == "__main__":
  a = int(raw_input("please enter number1:"))
  b = int(raw_input("please enter number2:"))
  print my_add(a,b)

