#!/usr/bin/python
import logging as l
l.info("this is an information")
l.debug("this is an debug information")
l.warning("this is an warning information")
l.error("this is an error information")
l.critical("this is an critical information")

