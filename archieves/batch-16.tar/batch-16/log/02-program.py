#!/usr/bin/python
import logging as l
l.basicConfig(filename='new.log',level=l.CRITICAL,format='%(asctime)s - %(levelname)s - %(message)s ',datefmt = '%c')
l.debug("this is an debug information")
l.info("this is an information")
l.warning("this is an warning information")
l.error("this is an error information")
l.critical("this is an critical information")
