#!/usr/bin/python
# while
# break
# continue
# sys.exit
# simple game of guessing numbers
import sys

status = raw_input("do you want to continue the game ?(y/n)")
if status == 'n':
	sys.exit()

num=7
#test = True

while True:
	my_num = int(raw_input("please enter the number:"))
	if my_num > num:
		print "you enter a number sligtly larger"
	elif my_num < num:
		print "you entered a number slightly smaller"
	elif my_num == num:
		print "congratulations !!! you the batman !!!"
		break

print "Thanks for playing the game !!! plese do revisit"