#!/usr/bin/python
import sys

try:
  num1 = int(raw_input("please enter the number 1:"))
  num2 = int(raw_input("please enter the number 2:"))
except ValueError,error:
  print "please enter the numbers only"
  print error
  #sys.exit(0)
 
try:  
  print "division : %d" %(num1/num2)
except ZeroDivisionError,error:
  print "Please do not enter denominator as zero"
  print error
except NameError,error:
  print "Please enter only numbers"
  print error
