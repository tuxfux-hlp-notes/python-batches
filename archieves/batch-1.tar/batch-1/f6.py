#!/usr/bin/python

number = 7
test = True
while test == True:
    guess = int(raw_input("Please enter the integer:"))
    yes_no = raw_input("Do you want to continue, 'quit' to exit:")
    if yes_no == 'quit':
      break
    if guess == number:
        print "Congo !! you have guessed the right number %d " %(number)
        test = False
    elif guess > 7:
        print "The number is slightly greater \n"
        test = True
    else:
        print "The number is slightly lesser \n"
        test = True
else:
    print "We are out of while loop"
    
