#!/usr/bin/python
print "today is a great day \n";
