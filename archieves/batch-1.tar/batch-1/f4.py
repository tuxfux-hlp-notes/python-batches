#!/usr/bin/python
array = ('a','b','c')

for i in array:
  print "The element of the array %s" %(i)

