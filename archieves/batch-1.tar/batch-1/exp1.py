#!/usr/bin/python

try:
  a = input('please enter your number 1:')
  b = input('please enter your number 2:')
except NameError,error:
  print "please enter numbers only \n"
  print "exception:", error
else:
  print "You enter the right number a:%d b:%d" %(a,b)

'''
try:
  print "division of both numbers:" , a/b
except ZeroDivisionError:
  print "we cannot divide by zero"
'''

