#!/usr/bin/python
import exceptions

try:
  a = input('please enter your number 1:')
except NameError:
  print "we should not enter zero"
else:
  print "the number a:%d" %(a)
