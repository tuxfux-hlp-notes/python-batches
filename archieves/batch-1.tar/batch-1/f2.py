#!/usr/bin/python
if  5 > 3:
    print "5 is greater than 3"
else:
    print "3 is greater than 5"
    
