#!/usr/bin/python
# Author: Tcloud
# date : 2/17/2014

#age = 20
#name = "pratyush"

age = input("Please enter you age:")
name = raw_input("Please enter your name:")

print "My name is %s and my age is %d" %(name,age) 
