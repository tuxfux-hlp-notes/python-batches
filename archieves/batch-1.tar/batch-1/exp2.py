#!/usr/bin/python

try:
  age = input('please enter your age:')
  print "my age is:", age
except NameError,error:
  print "please enter your age in numeric"


print "----- report --------"
print "We got the following error : %s" %(error)
