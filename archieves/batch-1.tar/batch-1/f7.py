#!/usr/bin/python

a = int(raw_input("please enter a number:"))
b = raw_input("plese enter a string:")

print type(a)
print type(b)
