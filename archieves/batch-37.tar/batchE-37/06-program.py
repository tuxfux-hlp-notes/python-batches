#!/usr/bin/python
master=['apple','banana','guava','dates','carrot','apple','banana']
slave=[]
for value in master:
    if master.count(value) > 1:
        master.remove(value)
        slave.append(value)
        
print master
print slave
