#!/usr/bin/python
# l.basicConfig?
# l.Formatter?
# man date
# https://docs.python.org/2/howto/logging.html
# https://docs.python.org/2/howto/logging-cookbook.html

import logging as l
l.basicConfig(filename='disk.txt',filemode='a',level=l.DEBUG,format='%(asctime)s - %(levelname)s - %(name)s - %(message)s',datefmt='%c')

# Application code
#l.debug("this is debug message")
disk_size = int(raw_input("please enter the disk size:"))
if disk_size < 50:
  l.info("The disk looks health")
elif disk_size > 50 and disk_size < 70:
  l.warning("The disk is getting filled up. - Please look")
elif disk_size > 70 and disk_size < 80:
  l.error("The disk filledup .. please clean it")
elif disk_size > 80:
  l.critical("The application is sleeping. Please wake it up.")

