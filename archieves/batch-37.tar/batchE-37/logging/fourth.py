#!/usr/bin/python
# Example of filehandler
# Do a better scripting
import logging
from subprocess import Popen,PIPE
import re

# create logger
logger = logging.getLogger('disk')    # logger
logger.setLevel(logging.DEBUG)        # filter

# create console handler and set level to debug
ch = logging.FileHandler(filename='mylog.txt')          # handler
ch.setLevel(logging.DEBUG)            # filter for handler

# create formatter
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')

# add formatter to ch
ch.setFormatter(formatter)

# add ch to logger
logger.addHandler(ch)

# Application code
#l.debug("this is debug message")
# disk_size = int(raw_input("please enter the disk size:"))
# disk_size = df -h / | tail -n 1|awk '{print $5}'|sed -e 's#%##'
p1 = Popen(["df","-h","/dev/sda1"], stdout=PIPE)
p2 = Popen(["tail", "-n","1"], stdin=p1.stdout, stdout=PIPE)
p1.stdout.close()  # Allow p1 to receive a SIGPIPE if p2 exits.
output = p2.communicate()[0]
#print output,type(output)
disk_size=int(re.search('([0-9])[%]',output).group(1))

if disk_size < 50:
  logger.info("The disk looks healthy")
elif disk_size > 50 and disk_size < 70:
  logger.warning("The disk is getting filled up. - Please look")
elif disk_size > 70 and disk_size < 80:
  logger.error("The disk filledup .. please clean it")
elif disk_size > 80:
  logger.critical("The application is sleeping. Please wake it up.")
  
  
  
