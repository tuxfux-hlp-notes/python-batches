#!/usr/bin/python
# l.basicConfig?
# l.Formatter?
# man date
# logger => root
# handler => filename='disk.txt'
# filter => level=l.DEBUG
# Formatter => format='%(asctime)s - %(levelname)s - %(name)s - %(message)s',datefmt='%c'
#l.basicConfig(filename='disk.txt',filemode='a',level=l.DEBUG,format='%(asctime)s - %(levelname)s - %(name)s - %(message)s',datefmt='%c')

import logging

# create logger
logger = logging.getLogger('disk')    # logger
logger.setLevel(logging.DEBUG)        # filter

# create console handler and set level to debug
ch = logging.StreamHandler()          # handler
ch.setLevel(logging.DEBUG)            # filter for handler

# create formatter
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s') # Formatter

# add formatter to ch
ch.setFormatter(formatter)  # Formatter

# add ch to logger
logger.addHandler(ch)       # handler

# Application code
#l.debug("this is debug message")
disk_size = int(raw_input("please enter the disk size:"))
if disk_size < 50:
  logger.info("The disk looks healthy")
elif disk_size > 50 and disk_size < 70:
  logger.warning("The disk is getting filled up. - Please look")
elif disk_size > 70 and disk_size < 80:
  logger.error("The disk filledup .. please clean it")
elif disk_size > 80:
  logger.critical("The application is sleeping. Please wake it up.")
