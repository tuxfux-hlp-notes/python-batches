#!/usr/bin/python
# continue : skipping an iteration.
absent = ['kumar','san','nas']
for student in ('nas','david','ruthu','kumar','mukesh','san'):
  if student in absent:
    continue
  print "report card {}".format(student)
