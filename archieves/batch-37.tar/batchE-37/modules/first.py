#!/usr/bin/python
version = 2.0

def my_add(a,b):
  ''' syntax: my_add(a,b)
      addition of strings and numbers '''
  return a + b
  
def my_sub(a,b):
  return a - b

def my_multi(a,b):
  return a * b
  
def my_div(a,b=0):
  return a/b
  
# Application code
if __name__ == '__main__':
  print "hello world!!!"
  print "addition of two numbers:{}".format(my_add(1,2))
  

