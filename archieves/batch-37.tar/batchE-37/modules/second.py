#!/usr/bin/python
import sys
sys.path.insert(0,'/home/tcloudost/python-examples/batchE-37/modules/extra')
import first as f

def my_add(a,b):
  ''' this is only for addition of numbers'''
  a = int(a)
  b = int(b)
  return a + b
  
print "addition of two numbers is {}".format(my_add(1,2))
print "addition of two string  is {}".format(f.my_add('hello',' world'))
