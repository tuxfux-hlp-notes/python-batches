#!/usr/bin/python
print "welcome to the market"
food_type = raw_input("please enter your food type:veg/fish/chicken/mutton:")

if food_type == 'veg':
  pass
elif food_type == 'fish':
  print "welcome to the fish market"
  fish_type = raw_input("please enter the fish type - (apollo/tuna/solomon/rohu):")
  if fish_type == 'apollo' or fish_type == 'APOLLO':
    print "what quantity of {} fish you want ?".format(fish_type)
    print "Do you want anything else?"
  elif fish_type == 'tuna':
    print "what quantity of {} fish you want ?".format(fish_type)
    print "Do you want anything else?"
  elif fish_type == 'solomon':
    print "what quantity of {} fish you want ?".format(fish_type)
    print "Do you want anything else?"
  else:
    print "your fish {} is not available".format(fish_type)
    print "How about chicken/veg/mutton"   
elif food_type == 'chicken':
  pass
elif food_type == 'mutton':
  pass
else:
  pass

