#!/usr/bin/python
num1 = int(raw_input("please enter the num1:"))
num2 = int(raw_input("please enter the num2:"))
print "sum of two numbers {}".format(num1+num2)

