#!/usr/bin/python
# Decorators:
# http://simeonfranklin.com/blog/2012/jul/1/python-decorators-in-12-steps/
'''
def divide(x,y):
  return x/y
  
def divide(x,y):
  try:
    x/y
  except Exception as e:
    return "we hit on an exception - {}".format(e)
  else:
    return x/y
'''

def upper(func_name):
  def inner(*args,**kwargs):
    try:
      func_name(*args)
    except Exception as e:
      return "{}".format(e)
    else:
      return func_name(*args)
  return inner

@upper
def divide(x,y):
  return x/y

@upper
def addition(x,y):
  return x + y
  
print divide(2,0)
print divide(4,2)
print divide('a',2)
print addition('1','1')
print addition(1,1)
print addition('a',1)



'''
one way of applying a decorator  
divide = upper(divide)
print divide(2,0)
print divide(4,2)
print divide('a',2)
'''
