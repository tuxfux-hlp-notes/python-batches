#!/usr/bin/python
# Usage:
# what is a class?
# how to define a class?
# class - variables(data) + function(methods)
# class variables vs instance variables.
# A function within a class needs to have a "self" variable.
# 

class car:
  no_of_wheels = 4
  color_of_body = 'red'
  def mycar(self):
    return "The no of wheels - {} and the color is {} ".format(self.no_of_wheels,self.color_of_body)
  
print type(car)   # class
print type(car()) # object
Audi = car()  # Audi object
print dir(Audi)
print Audi.no_of_wheels
print Audi.color_of_body
print Audi.mycar()
Skoda = car()
print Skoda.no_of_wheels
Skoda.color_of_body = 'green'
print Skoda.color_of_body
print dir(Skoda)
print Skoda.mycar()

'''
class car():
class car:
class car(object):
'''
