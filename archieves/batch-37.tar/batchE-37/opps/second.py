#!/usr/bin/python
# constructor : __init__

class shape:
   def __init__(self,x,y):
     self.x = x
     self.y = y
   description = "This shape has not been described yet"
   author = "Nobody has claimed to make this shape yet"

   def area(self):
     return self.x * self.y
   def perimeter(self):
     return 2 * self.x + 2 * self.y
   def describe(self,text):
     self.description = text
   def authorname(self,text):
     self.author = text
   def scalesize(self,scale):
     self.x = self.x * scale
     self.x = self.y * scale

rectangle = shape(100,45)

print rectangle.author
print rectangle.description
print rectangle.area()
print rectangle.perimeter()
print rectangle.describe(" wide rectangle more than twice as wide as tall")
print rectangle.description
print rectangle.scalesize(0.5)
print rectangle.area()

square = shape(100,100)
print square.author
print square.description
print dir(square)
print square.x,square.y
print square.area()

