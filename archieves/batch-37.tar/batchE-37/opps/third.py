#!/usr/bin/python
# inheritance
# parent class - super class
# child class  - sub class

class Mother:
  my_color_eyes='brown'
  my_gender='f'
  my_hand='left'

class Father:
  my_color_eyes='black'
  my_gender='m'
  
class child(Father,Mother):
  my_gender='m'
  
kumar = child()
print kumar.my_gender
print kumar.my_color_eyes
print kumar.my_hand
  
'''
In [4]: raise kumar
---------------------------------------------------------------------------
NameError                                 Traceback (most recent call last)
<ipython-input-4-b7bc7b53084a> in <module>()
----> 1 raise kumar

NameError: name 'kumar' is not defined

In [5]: raise SyntaxError
  File "<string>", line unknown
SyntaxError


In [6]: # SyntaxError is part of exception class

In [7]: class kumar(Exceptions):
   ...:     pass
   ...: 
---------------------------------------------------------------------------
NameError                                 Traceback (most recent call last)
<ipython-input-7-06f0ff29ae58> in <module>()
----> 1 class kumar(Exceptions):
      2     pass
      3 

NameError: name 'Exceptions' is not defined

In [8]: class kumar(Exception):
    pass
   ...: 

In [9]: raise kumar
---------------------------------------------------------------------------
kumar                                     Traceback (most recent call last)
<ipython-input-9-b7bc7b53084a> in <module>()
----> 1 raise kumar

kumar: 

'''
