#!/usr/bin/python
# Usage: check the age of animals in the zoo.
# min age = 0,max age = 150
# exception/Inheritance

animal_age = int(raw_input("Age of the animal:"))

class InvalidAge(Exception):
  pass

def validate_age(animal_age):
  if animal_age < 0 or animal_age >= 150:
    raise InvalidAge
  else:
    return "The age of the animal is {}".format(animal_age)
  
try:
  print validate_age(animal_age)
except InvalidAge:
  print "The age you entered is invalid"
