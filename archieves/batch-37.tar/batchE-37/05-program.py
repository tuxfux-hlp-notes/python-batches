#!/usr/bin/python
import sys
#print sys.argv
if len(sys.argv) != 3:
  print "Syntax error: ./{} {} {}".format(sys.argv[0],'num1','num2')
  sys.exit()
else:
  print int(sys.argv[1]) + int(sys.argv[2])
  

  
