#!/usr/bin/env python 
print "Content-type: text/html" 
print 
print "<html>"
print "<head>"
print "<title>"
print "CGI program"
print "</title>"
print "</head>"
print "<body>"
print "<h1>hello world</h1>"
print "</body>"
print "</html>"
