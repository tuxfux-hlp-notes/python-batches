#!/usr/bin/python
import re
agree = raw_input("do you want to play the game - (yes/no):")
#if agree == 'yes':
if re.match(agree,'yes',re.I):
  print "welcome to the game"
else:
  print "hope you join next time"
