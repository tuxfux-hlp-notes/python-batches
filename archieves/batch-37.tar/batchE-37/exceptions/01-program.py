#!/usr/bin/python
# try..except..else..finally
# try -> computation
# except -> exception handling
# else -> out of computation
# finally -> block which run in all case
# case I : valid values .. try .. else .. finally
# case II : in valid values .. know exception .. try .. except .. finally
# case III : in valid values .. unknow exception .. try .. finally .. exception bombed.

try:
  num1 = int(raw_input("please enter a number:"))
  num2 = int(raw_input("please enter a number:"))
  result = num1/num2
except ValueError,error:
  print "please enter the numbers"
  print error
except ZeroDivisionError,error:
  print "make sure denominator is non-zero"
  print error
else:
  print result


'''
Example 5:

try:
  num1 = int(raw_input("please enter a number:"))
  num2 = int(raw_input("please enter a number:"))
  result = num1/num2
except ValueError,error:
  print "please enter the numbers"
  print error
except ZeroDivisionError,error:
  print "make sure denominator is non-zero"
  print error
else:
  print result

Example 4:

try:
  num1 = int(raw_input("please enter a number:"))
  num2 = int(raw_input("please enter a number:"))
  result = num1/num2
except ValueError:
  print "please enter the numbers"
else:
  print result
finally:
  print "ALL is well"

Example 3:

try:
  num1 = int(raw_input("please enter a number:"))
  num2 = int(raw_input("please enter a number:"))
  result = num1/num2
except (ValueError,ZeroDivisionError):
  print "please enter the numbers.Make sure your denominator is non-zero"
else:
  print result

try:
  num1 = int(raw_input("please enter a number:"))
  num2 = int(raw_input("please enter a number:"))
  result = num1/num2
except ValueError:
  print "please enter the numbers"
except ZeroDivisionError:
  print "make sure denominator is non-zero"
else:
  print result

Example 2:

try:
  num1 = int(raw_input("please enter a number:"))
  num2 = int(raw_input("please enter a number:"))
  result = num1/num2
except:
  print "please enter the numbers and make sure denominator is non-zero"
else:
  print result

Example 1:

num1 = int(raw_input("please enter a number:"))
num2 = int(raw_input("please enter a number:"))
result = num1/num2
print result




'''
