#!/usr/bin/python
# continue : skipping an iteration.
for student in ('david','ruthu','kumar','mukesh'):
  if student == 'kumar':
    #continue
    #break
    pass
  print "report card {}".format(student)
  
