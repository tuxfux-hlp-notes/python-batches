#!/usr/bin/python
import pdb
pdb.set_trace()
for value in range(1,11):
  print value
