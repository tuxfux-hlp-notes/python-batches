#!/usr/bin/python
# game
# break : will take us abruptly out of the loop,note: not out of the program.
# sys.exit : will take you out of the program.

import sys

yn = raw_input("do you really want to play the game:")
if yn == 'n':
  sys.exit()

number=7
#test=True

while True:
  #print "welcome to the game"
  guess = int(raw_input("please enter the number:"))
  if guess > number:
    print "the number you guessed is sligtly larger"
  elif guess < number:
    print "the number you guessed is sligtly smaller"
  elif guess == number:
    print "Congo!!! the number you guessed is correct"
    #test=False
    break
    
    
print "Thanks for playing the game"
