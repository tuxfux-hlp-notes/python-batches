#!/usr/bin/env python
# Author : kumar
# date: 
# log : 
#     : Dec 10 -  mukesh - i made world intresting
print ("hello world !!! :)")
