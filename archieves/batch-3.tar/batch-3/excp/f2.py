#!/usr/bin/python
import sys


try:
 value1 = input("Please enter the value1:")
 value2 = input("Please enter the value2:")
except NameError,error:
 print "Please enter only numbers !!!"

print "ERROR: %s" %(error)
