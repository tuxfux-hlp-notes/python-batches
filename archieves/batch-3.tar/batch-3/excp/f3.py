#!/usr/bin/python
import sys


try:
 value1 = input("Please enter the value1:")
 value2 = input("Please enter the value2:")
except NameError:
 print "Please enter only numbers !!!"
 sys.exit(1)
else:
 print "The division of two numbers:" , value1/value2
