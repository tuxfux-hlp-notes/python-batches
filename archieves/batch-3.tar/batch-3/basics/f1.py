a= 1
b = 2
if a > b:
    print "%d is greater than %d" %(a,b)
else:
    print "%d is greater than %d" %(b,a)
    
