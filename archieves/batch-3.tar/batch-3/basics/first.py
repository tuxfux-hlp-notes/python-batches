#!/usr/bin/python

value = int(raw_input('please enter the first number:'))
value1 = int(raw_input('please enter the second number:'))

# the add variable is for storing sum of value and value1
add = value + value1

print "Addition of both %d and %d is %d" %(value,value1,add)

raw_input('.. please hit enter key ...')

