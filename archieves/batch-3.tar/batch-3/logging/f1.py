#!/usr/bin/python
import logging

logging.basicConfig(filename="app.log",format='%(asctime)s - %(levelname)s - %(name)s - %(message)s',level=logging.DEBUG,datefmt='%m/%d/%Y %I:%M:%S %p')
logging.debug("Hello this is a debug message \n")
logging.info("Hello this is information \n")
logging.warning("Hello this is a warning \n");
logging.error("Hello this is an error \n");
logging.critical("Hello this an critical error \n");
