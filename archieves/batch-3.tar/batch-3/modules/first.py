#!/usr/bin/python
version = '2.0'
def hello():
  ''' this is just for printing hello '''
  print "hello today is modules class"
def add(a=1,b=2):
  ''' this is an addition program '''
  sum = a + b
  return sum

if __name__ == '__main__':
  print hello()
  sum = add()
  print sum
  print version
else:
  print "Hello this has to be part of my modules"
