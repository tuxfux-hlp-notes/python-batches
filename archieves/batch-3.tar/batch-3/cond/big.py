#!/usr/bin/python

a = int(raw_input("please enter number:"))
b = int(raw_input("please enter number:"))
c = int(raw_input("please enter number:"))

if a > b and a > c:
  print "%d is greater" %(a)
  print "a is greater"
elif b > c and b > a:
    print "%d is greater" %(b)
    print "c is greater"
else:
  print "%d is greater" %(c)

  

