#!/usr/bin/python
import re
friends=['purna','dinesh','asish','vimal','sishir']
reg = re.compile('^.....$')
for i in friends:
    if reg.match(i):
        print i
        
