#!/usr/bin/python
first=['the','dead','parrot','sketch']
for i in first:
  print (i[:first.index(i)]).upper() + i[first.index(i):]
