#!/usr/bin/python
import sys
if len(sys.argv) != 3:
  print "syntax:./%s %s %s" %(sys.argv[0],'value1','value2')
  sys.exit()

print sys.argv
(value1,value2)=sys.argv[1:]
print value1,value2
