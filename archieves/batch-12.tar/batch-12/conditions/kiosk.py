#!/usr/bin/env python

print "Welcome to the market"
options = raw_input("do you want chicken/fish/mutton:")
if options == 'fish' or options == 'Fish':
  fish_type=raw_input("what is the fish type you need:")
  if fish_type == 'toffu' or fish_type=='TOFFU':
    print "we have the %s fish available" %fish_type
    print "how much quantity you need"
  elif fish_type == 'peru':
    print "we have the %s fish available" %fish_type
    print "how much quantity you need"
  else:
    print "we dont have the %s fish type" %fish_type
    print "please come back"
elif options == 'chicken' or options == 'Chicken':
  print "we have the chicken ready"
  chicken_type=raw_input("please enter the chicken type")
  if chicken_type == "boiler":
   print "the chicken %s is available" %chicken_type
  else:
   print "The chicken you asked is not available"
   print "Please come back"
  elif options == 'mutton':
   pass
else:
  pass

