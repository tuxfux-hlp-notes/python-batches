#!/usr/bin/python
# binary - 1111
# decimals - 1 * 2**3 + 1 ** 2**2 + 1 * 2**1 + 1 * 2**0

binary = raw_input("please enter the binary number:")
length=len(binary)
count=0

for value in binary:
  length= length - 1
  count = count + int(value) * 2**length

print "decimal conversion of binary %s is %d" %(binary,count)  
