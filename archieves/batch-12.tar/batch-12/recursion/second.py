#!/usr/bin/python
import sys

number=7
test=True

game = raw_input("do you want to continue with the game(y/n):")
if game == 'n':
  sys.exit()

while test:
  num = int(raw_input("please enter the number:"))
  if number > num:
    print "The number you chose is slightly greater"
  elif number < num:
    print "The number you chose is slightly lesser"
  elif number == num:
    print "Congratulations !!! you chose the right number"
    break

print "Thanks for playing the game."
