#!/usr/bin/python
# Author:
# log:
# 

name = raw_input("please enter the name of the person:")
roll_num = raw_input("please enter the roll number of the person:")
print "The name is %s and roll number is %s" %(name,roll_num)
raw_input(".. press any key to exit ..")
