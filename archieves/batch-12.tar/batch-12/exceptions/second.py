#!/usr/bin/python

try:
  num1 = int(raw_input("please enter the first number:"))
  num2 = int(raw_input("please enter the second number:"))
  print num1/num2
except ValueError,error:
  print "please enter a valid numbers"
  print error
except ZeroDivisionError,error:
  print "you should have denominator other that zero"
  print error

