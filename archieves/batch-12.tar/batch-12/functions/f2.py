#!/usr/bin/python


def my_multiply(number,default):
  for i in range(1,(default + 1)):
   print "%d * %d = %d" %(number,i,number*i)

my_multiply(number=2,20)
  


