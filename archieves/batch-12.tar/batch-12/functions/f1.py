#!/usr/bin/python

def my_func2(a,b):
  if type(a) == int and type(b) == int:
    print a,b
    print a+b
  else:
    print "please enter integers"

my_func2(1,2)
my_func2('1','2')
