#!/usr/bin/python

def my_func2(a,b):
  if type(a) == int and type(b) == int:
    return a+b
  else:
    print "please enter integers"

my_sum=my_func2(1,2)
print "my_sum:%d" %(my_sum)
