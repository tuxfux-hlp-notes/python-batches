#!/usr/bin/python
import logging as l
l.basicConfig(filename="log.txt",format='%(asctime)s - %(levelname)s - %(message)s',level=l.DEBUG,datefmt='%F %r')
l.debug("hello this is debug information")
l.info("hello this is information")
l.warning("hello this is warning")
l.critical("hello this is critical")
l.error("hello this is error")

