#!/usr/bin/python
import logging as l
l.basicConfig(filename="file.txt",format='%(asctime)s - %(levelname)s - %(message)s',level=l.DEBUG,datefmt='%F %r')
size = int(raw_input("please enter the size of the disk:"))
if size > 20 and size < 50:
  l.info("The disk is GREEN")
elif size > 50 and size < 70:
  l.warning("The disk could become FULL")
elif size > 70 and size < 90:
  l.error("The disk is becoming FULL")
elif size > 90:
  l.critical("My friend APACHE is complaining")

