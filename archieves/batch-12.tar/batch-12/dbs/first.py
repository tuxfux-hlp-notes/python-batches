#!/usr/bin/python
import MySQLdb as mdb
con = mdb.connect('localhost','test_user1','test_user1','my_data')
cur = con.cursor()
cur.execute("select user()")
username = cur.fetchone()
print "I am connnected to database using user{}".format(username)

