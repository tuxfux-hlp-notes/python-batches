#!/usr/bin/python

S_version='1.0'
def S_fun():
  pass
def S_fun1():
  pass
