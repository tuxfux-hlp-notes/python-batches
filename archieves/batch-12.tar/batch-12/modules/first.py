#!/usr/bin/python
# Usage: understaing the modules.

my_version='2.0'
def my_hello():
  '''
     hello this is just an example
  '''
  print "Hello everyone"

if __name__ == '__main__':
  print "hello today is module class."
  my_hello()
  print my_version
