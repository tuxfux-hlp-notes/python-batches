#!/usr/bin/python

def Lfirst():
  print "Hello this is my Linux first module"

def Lsecond():
  print "Hello this is my linux second module"
