#!/usr/bin/python

def SLfirst():
  print "Hello this is my Linux first module"

def SLsecond():
  print "Hello this is my linux second module"
