#!/usr/bin/python

import sys

sys.path.append('/home/visitor/python-examples/batch-5/modules/')

import f1

f1.start()
print "The version of my program is %s" %(f1.version)
f1.stop()

