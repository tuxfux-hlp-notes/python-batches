#!/usr/bin/python

if __name__ == '__main__':
  print "we are running the main program"
else:
  print "we are using the module part"

  version = '2.0'

  def start():
    print "function started \n"

  def stop():
    print "function stopped \n"
