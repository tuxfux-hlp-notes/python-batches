#!/usr/bin/python

num1 = int(raw_input("please enter the number1: \n"))
num2 = int(raw_input("please enter the number2: \n"))
num3 = int(raw_input("please enter the number3: \n"))

if num1 > num2 and num1 > num3:
  print "%d is greater number" %num1
elif num2 > num1 and num2 > num3:
  print "%d is greater number" %num2
else:
  print "%d is greater number" %num3
  
