#!/usr/bin/python

animal = raw_input("please enter the animal species \n")

if animal == 'fish':
  print "The animal is fish"
  fish = raw_input("Please enter the fish name.\n")
  if fish == "peru":
    print "my fish name is %s" %fish
  elif fish == "toffu":
    print "my fish name is %s" %fish
  elif fish == "solomon":
    pass
  else:
    print "we dont have the %s" %fish
else:
        print "The animal is not fish"
