#!/usr/bin/python

animal = raw_input("please enter the animal species \n")

if animal == 'fish':
  pass
else:
  pass
