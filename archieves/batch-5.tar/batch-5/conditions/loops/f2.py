#!/usr/bin/python
import sys

test = True
number = 7

while test:
  answer = raw_input("please enter the answer:\n")
  if answer == 'n':
    sys.exit(0)
  else:
    guess = int(raw_input("please enter the number: \n"))
    print "lets continue with the game"
    if guess > 7:
      print "the number you guessed is slightly greater"
    elif guess < 7:
      print "the number you guessed is slightly less"
    else:
      print "you guessed the right number %d" %guess
      break

print "Thanks for playing the game"


