#!/usr/bin/python
import sys

test = True

while test:
  answer = raw_input("please enter the answer:\n")
  if answer == 'n':
    sys.exit(0)
  else:
    print "lets continue with the game"
    break

print "we are now out of program"


