#!/usr/bin/python

name = raw_input("please enter your name? \n")
age = int(raw_input("please enter your age? \n"))

print "my name is %s and my age is %d" %(name,age)

raw_input(".... please enter a key to move on ... \n" )
