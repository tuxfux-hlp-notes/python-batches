name = raw_input("what is your name?")
print name
type(name)
age = input("what is your age?")
