#!/usr/bin/python
name = raw_input("what is your name?")
print name
age = input("what is your age?")
print age
