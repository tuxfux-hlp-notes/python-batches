#!/usr/bin/python

try:
  value1 = int(raw_input("please enter number 1:"))
  value2 = int(raw_input("please enter number 2:"))
except ValueError:
  print "Buddy.. its number \n"

try:
  print "division of numbers", value1/value2
except  ValueError,error:
  print "Buddy .. no number given .. try again .. \n"
  print "ERROR:{}".format(error)
except ZeroDivisionError,error:
  print "Zero is not the number you would enter \n"
  print "ERROR:{}".format(error)
except NameError,error:
  print "value is not defined"
  print "ERROR:{}".format(error)
else:
  print "The division of numbers is success \n"
