#!/usr/bin/python

try:
  value1 = int(raw_input("please enter number 1:"))
  value2 = int(raw_input("please enter number 2:"))
except ValueError,error:
  print "Buddy.. its number \n"
  print "ERROR:{}".format(error)
else:
  if value2 == 0:
    raise ArithmeticError,"we cannot divide by 0"
  else:
    print value1,value2
