#!/usr/bin/python
# shabang or shebang
# Author:
# Date:
# Purpose:
# Logs:

print "welcome to the python class \n";

