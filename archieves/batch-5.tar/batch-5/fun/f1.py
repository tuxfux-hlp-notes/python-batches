#!/usr/bin/python


def my_function():
  print "hello this is my first function \n";

my_function()
