#!/usr/bin/python
import logging as L

value = int(raw_input("Please enter the disk space"))
L.basicConfig(filename='log.txt',filemode='a',datefmt='%x-%u-%T-%p',format='%(asctime)s %(levelname)s - %(message)s',level=L.INFO)

if value == 100:
  L.critical("we are in a critical state")
elif value < 90 and value > 80:
  L.warning("This is warning information")
elif value < 80 and value > 70:
  L.error("This is error information")
else:
  L.debug("All is fine")

#L.info("This is a infomation")
#L.debug("This is debug information")
#L.error("This is error information")
#L.warning("This is warning information")
#L.critical("This is critical information")


